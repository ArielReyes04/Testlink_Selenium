-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 02-09-2024 a las 08:55:58
-- Versión del servidor: 8.0.17
-- Versión de PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `aura spa`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `spa_categorias`
--

CREATE TABLE `spa_categorias` (
  `id_categoria` int(11) NOT NULL,
  `categoria` varchar(101) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `estado` varchar(101) NOT NULL DEFAULT 'activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `spa_categorias`
--

INSERT INTO `spa_categorias` (`id_categoria`, `categoria`, `descripcion`, `estado`) VALUES
(11, 'Tintes', 'Tintes para el cabello/coloracion', 'activo'),
(12, 'Esmaltes', 'esmaltes para pintar uñas', 'activo'),
(13, 'Cremas', 'Cremas para uso ', 'activo'),
(14, 'Cosmeticos', 'cosmeticos para señoita', 'activo'),
(15, 'Shampoo', 'shampoos y acondicionador para el cabello', 'activo'),
(16, 'Accesorios', 'Accesorios de belleza', 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `spa_clientes`
--

CREATE TABLE `spa_clientes` (
  `id_cliente` int(11) NOT NULL,
  `nombres` varchar(60) NOT NULL,
  `cedula` varchar(10) NOT NULL,
  `telefono` varchar(10) NOT NULL,
  `direccion` varchar(30) NOT NULL,
  `email` varchar(40) NOT NULL,
  `fnac` date NOT NULL,
  `estado` varchar(10) NOT NULL DEFAULT 'activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `spa_clientes`
--

INSERT INTO `spa_clientes` (`id_cliente`, `nombres`, `cedula`, `telefono`, `direccion`, `email`, `fnac`, `estado`) VALUES
(13, 'jeffersonss', '1756300271', '0999945031', 'Duran', 'asdasdsa@ads', '2003-12-07', 'activo'),
(14, 'Jeremy Cuadrado', '1754611976', '0995854456', 'Chillogallo', 'jacuadrado1@espe.edu.ec', '2003-02-06', 'activo'),
(15, 'Justin Villarroel', '1805386206', '0996459938', 'Baños', 'jjvillarroel1@espe.edu.ec', '2003-09-06', 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `spa_facturas`
--

CREATE TABLE `spa_facturas` (
  `Id_factura` int(100) NOT NULL,
  `cedula_cliente` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `cedula_vendedor` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fecha_emision` datetime NOT NULL,
  `productos_id_cantida` varchar(300) NOT NULL,
  `total_sin_iva` float NOT NULL,
  `iva` float NOT NULL,
  `Valor_Total` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `spa_facturas`
--

INSERT INTO `spa_facturas` (`Id_factura`, `cedula_cliente`, `cedula_vendedor`, `fecha_emision`, `productos_id_cantida`, `total_sin_iva`, `iva`, `Valor_Total`) VALUES
(22, '1754611976', 'Vendedor_C', '2024-09-02 01:17:09', '[{\"codigo\":\"C0001\",\"cantidad\":1},{\"codigo\":\"F0001\",\"cantidad\":6},{\"codigo\":\"B0001\",\"cantidad\":2},{\"codigo\":\"P0001\",\"cantidad\":1},{\"codigo\":\"41\",\"cantidad\":1}]', 59.35, 8.9, 68.25),
(23, '1805386206', 'Vendedor_C', '2024-09-02 01:17:45', '[{\"codigo\":\"C0001\",\"cantidad\":2},{\"codigo\":\"F0001\",\"cantidad\":5},{\"codigo\":\"B0001\",\"cantidad\":1},{\"codigo\":\"S0001\",\"cantidad\":3},{\"codigo\":\"42\",\"cantidad\":1}]', 77.7, 11.65, 89.36),
(24, '1756300271', 'Vendedor_C', '2024-09-02 01:18:35', '[{\"codigo\":\"41\",\"cantidad\":1},{\"codigo\":\"42\",\"cantidad\":1},{\"codigo\":\"43\",\"cantidad\":1},{\"codigo\":\"F0001\",\"cantidad\":18}]', 116, 17.4, 133.4),
(25, '1805386206', 'Vendedor_C', '2024-09-02 02:05:46', '[{\"codigo\":\"F0001\",\"cantidad\":2},{\"codigo\":\"S0001\",\"cantidad\":3},{\"codigo\":\"B0001\",\"cantidad\":2}]', 46, 6.9, 52.9),
(26, '1756300271', 'Vendedor_C', '2024-09-02 03:11:40', '[{\"codigo\":\"C0001\",\"cantidad\":1}]', 7.35, 1.1, 8.45),
(27, '1756300271', 'Vendedor_C', '2024-09-02 03:18:17', '[{\"codigo\":\"T0001\",\"cantidad\":1}]', 2.5, 0.38, 2.88),
(28, '1756300271', 'Vendedor_C', '2024-09-02 03:22:11', '[{\"codigo\":\"F0001\",\"cantidad\":1}]', 5, 0.75, 5.75),
(29, '1756300271', 'Vendedor_C', '2024-09-02 03:23:00', '[{\"codigo\":\"F0001\",\"cantidad\":1}]', 5, 0.75, 5.75),
(30, '1756300271', 'Vendedor_C', '2024-09-02 03:23:34', '[{\"codigo\":\"F0001\",\"cantidad\":1}]', 5, 0.75, 5.75),
(31, '1756300271', 'Vendedor_C', '2024-09-02 03:26:22', '[{\"codigo\":\"S0001\",\"cantidad\":1},{\"codigo\":\"F0001\",\"cantidad\":1}]', 15, 2.25, 17.25),
(32, '1756300271', 'Vendedor_C', '2024-09-02 03:27:17', '[{\"codigo\":\"F0001\",\"cantidad\":2}]', 10, 1.5, 11.5),
(33, '1756300271', 'Vendedor_C', '2024-09-02 03:27:57', '[{\"codigo\":\"41\",\"cantidad\":1}]', 12, 1.8, 13.8),
(34, '1756300271', 'Vendedor_C', '2024-09-02 03:29:50', '[{\"codigo\":\"F0001\",\"cantidad\":2}]', 10, 1.5, 11.5),
(35, '1756300271', 'Vendedor_C', '2024-09-02 03:31:03', '[{\"codigo\":\"P0001\",\"cantidad\":2}]', 8, 1.2, 9.2),
(36, '1756300271', 'Vendedor_C', '2024-09-02 03:43:23', '[{\"codigo\":\"F0001\",\"cantidad\":1}]', 5, 0.75, 5.75),
(37, '1756300271', 'Vendedor_C', '2024-09-02 03:46:18', '[{\"codigo\":\"F0001\",\"cantidad\":1}]', 5, 0.75, 5.75),
(38, '1756300271', 'Vendedor_C', '2024-09-02 03:50:36', '[{\"codigo\":\"F0001\",\"cantidad\":3},{\"codigo\":\"41\",\"cantidad\":1}]', 27, 4.05, 31.05),
(39, '1756300271', 'Vendedor_C', '2024-09-02 03:53:29', '[{\"codigo\":\"F0001\",\"cantidad\":2},{\"codigo\":\"43\",\"cantidad\":1}]', 19, 2.85, 21.85);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `spa_modulos`
--

CREATE TABLE `spa_modulos` (
  `id_modulos` int(11) NOT NULL,
  `modulo` varchar(50) NOT NULL,
  `descripcion` text NOT NULL,
  `direccion_php` varchar(255) NOT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `spa_modulos`
--

INSERT INTO `spa_modulos` (`id_modulos`, `modulo`, `descripcion`, `direccion_php`, `estado`) VALUES
(1, 'Usuarios', 'Gestión de usuarios', 'usuarios.php', 'activo'),
(2, 'Ventas', 'Gestión de ventas', 'ventas.php', 'activo'),
(3, 'Clientes', 'Gestión de clientes', 'clientes.php', 'activo'),
(4, 'Reportes', 'Gestión de reportes', 'reportes.php', 'activo'),
(5, 'Bodega', 'Gestión de bodega', 'bodega.php', 'activo'),
(6, 'Servicios', 'Gestion de Servicios', 'servicios.php	', 'activo'),
(7, 'Perfiles', 'Gestión de perfiles', 'perfiles.php', 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `spa_perfiles`
--

CREATE TABLE `spa_perfiles` (
  `id_perfil` int(11) NOT NULL,
  `perfil` varchar(50) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `modulos_acceso` varchar(100) NOT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `spa_perfiles`
--

INSERT INTO `spa_perfiles` (`id_perfil`, `perfil`, `descripcion`, `modulos_acceso`, `estado`) VALUES
(23, 'administrador', 'Tiene acceso total\r\n', 'Usuarios,Ventas,Clientes,Reportes,Bodega,Servicios,Perfiles', 'activo'),
(24, 'Bodegero', 'Tiene acceso a ciertas cosas como el bodeguero del spa\r\n', 'Reportes,Bodega', 'activo'),
(25, 'Ventas', 'Tiene a ciertas cosas de ventas como personal de ventas encargados de todo lo que son las ventas ', 'Ventas,Clientes,Servicios,Reportes', 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `spa_productos`
--

CREATE TABLE `spa_productos` (
  `id` int(100) NOT NULL,
  `nombre_producto` varchar(20) NOT NULL,
  `codigo_producto` varchar(10) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` float NOT NULL,
  `descripcion` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `categoria` varchar(20) NOT NULL,
  `fechaIngreso` datetime NOT NULL,
  `estado` varchar(10) NOT NULL DEFAULT 'activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `spa_productos`
--

INSERT INTO `spa_productos` (`id`, `nombre_producto`, `codigo_producto`, `cantidad`, `precio_unitario`, `descripcion`, `categoria`, `fechaIngreso`, `estado`) VALUES
(45, 'Tintes Nutrisse', 'C0001', 5, 7.35, 'Semi permanente', 'Tintes', '2024-08-31 20:57:17', 'inactivo'),
(46, 'Pinta unas juans', 'P0001', 2, 4, 'Pinta uñas con varias tonalidades', 'Esmaltes', '2024-08-31 20:59:22', 'activo'),
(47, 'Crema Facial', 'F0001', 46, 5, 'Crema facial de alta calidad', 'Cremas', '2024-08-31 21:00:56', 'inactivo'),
(48, 'Base tono natural', 'B0001', 7, 3, 'Base para pieles sensibles ', 'Cosmeticos', '2024-08-31 21:03:01', 'activo'),
(49, 'Shampoo tio nacho', 'S0001', 1, 10, 'Shampoo anti caspa', 'Shampoo', '2024-08-31 21:05:33', 'inactivo'),
(50, 'Tijeras', 'T0001', 9, 2.5, 'Tijeras para cortar el cabello', 'Accesorios', '2024-08-31 21:10:20', 'activo'),
(51, 'gel', '5d6sdf4', 6, 2, '2', 'Shampoo', '2024-08-31 23:22:48', 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `spa_reportes`
--

CREATE TABLE `spa_reportes` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `tipo_cambio` varchar(50) DEFAULT NULL,
  `entidad` varchar(50) DEFAULT NULL,
  `id_entidad` int(11) DEFAULT NULL,
  `descripcion` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fecha_hora` datetime DEFAULT NULL,
  `ip_usuario` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `spa_reportes`
--

INSERT INTO `spa_reportes` (`id`, `usuario`, `tipo_cambio`, `entidad`, `id_entidad`, `descripcion`, `fecha_hora`, `ip_usuario`) VALUES
(9, NULL, 'Nuevo Cliente', 'Cliente', 19, 'Se creó el cliente \'Manuel Nuñez\' con correo \'ijwdoiwajdi@fiejfoi.ci\'.', '2024-09-01 20:48:21', '::1'),
(10, NULL, 'Cambio de estado del Cliente: se encuentra \'inacti', 'Cliente', 18, 'El estado del cliente con ID 18 fue cambiado a \'inactivo\'.', '2024-09-01 20:49:11', '::1'),
(11, NULL, 'Actualización Cliente', 'Cliente', 16, 'Se actualizó el cliente \'jdowajdoiwajohhg\' con correo \'joshuajvb0@espe.edu.ec\'.', '2024-09-01 20:49:37', '::1'),
(16, NULL, 'Cambio de estado del Cliente: se encuentra \'inacti', 'Cliente', 17, 'El estado del cliente con ID 17 fue cambiado a \'inactivo\'.', '2024-09-01 21:17:05', '::1'),
(17, NULL, 'Desactivación de Producto', 'Producto', 47, 'El estado del producto con ID 47 fue cambiado a \'inactivo\'.', '2024-09-01 21:17:47', '::1'),
(19, NULL, 'Cambio Estado Servicio', 'Servicio', 2, 'Se actualizo el estado del servicio \'\' a \'activo\'.', '2024-09-01 21:34:20', '::1'),
(20, NULL, 'Cambio de estado del Cliente: se encuentra \'activo', 'Cliente', 13, 'El estado del cliente con ID 13 fue cambiado a \'activo\'.', '2024-09-01 23:44:40', '::1'),
(21, NULL, 'Cambio de estado del Cliente: se encuentra \'inacti', 'Cliente', 13, 'El estado del cliente con ID 13 fue cambiado a \'inactivo\'.', '2024-09-01 23:44:52', '::1'),
(22, NULL, 'Cambio de estado del Cliente: se encuentra \'activo', 'Cliente', 13, 'El estado del cliente con ID 13 fue cambiado a \'activo\'.', '2024-09-01 23:45:09', '::1'),
(23, NULL, 'Cambio Estado Servicio', 'Servicio', 16, 'Se actualizo el estado del servicio \'\' a \'inactivo\'.', '2024-09-02 00:21:40', '::1'),
(24, NULL, 'Desactivación de Producto', 'Producto', 45, 'El estado del producto con ID 45 fue cambiado a \'inactivo\'.', '2024-09-02 00:23:10', '::1'),
(25, NULL, 'Nuevo Cliente', 'Cliente', 14, 'Se creó el cliente \'Jeremy Cuadrado\' con correo \'jacuadrado1@espe.edu.ec\'.', '2024-09-02 01:10:16', '::1'),
(26, NULL, 'Actualización Cliente', 'Cliente', 13, 'Se actualizó el cliente \'jeffersonss\' con correo \'asdasdsa@ads\'.', '2024-09-02 01:11:16', '::1'),
(27, NULL, 'Nuevo Cliente', 'Cliente', 15, 'Se creó el cliente \'Justin Villarroel\' con correo \'jjvillarroel1@espe.edu.ec\'.', '2024-09-02 01:11:54', '::1'),
(28, NULL, 'Aumento de Cantidad', 'Producto', 45, 'Se aumentó la cantidad del producto con ID 45 en 10 unidades.', '2024-09-02 01:12:39', '::1'),
(29, NULL, 'Aumento de Cantidad', 'Producto', 46, 'Se aumentó la cantidad del producto con ID 46 en 6 unidades.', '2024-09-02 01:12:46', '::1'),
(30, NULL, 'Aumento de Cantidad', 'Producto', 47, 'Se aumentó la cantidad del producto con ID 47 en 10 unidades.', '2024-09-02 01:12:50', '::1'),
(31, NULL, 'Aumento de Cantidad', 'Producto', 51, 'Se aumentó la cantidad del producto con ID 51 en 5 unidades.', '2024-09-02 01:13:02', '::1'),
(32, NULL, 'Aumento de Cantidad', 'Producto', 50, 'Se aumentó la cantidad del producto con ID 50 en 10 unidades.', '2024-09-02 01:13:10', '::1'),
(33, NULL, 'Aumento de Cantidad', 'Producto', 48, 'Se aumentó la cantidad del producto con ID 48 en 10 unidades.', '2024-09-02 01:13:16', '::1'),
(34, NULL, 'Aumento de Cantidad', 'Producto', 49, 'Se aumentó la cantidad del producto con ID 49 en 6 unidades.', '2024-09-02 01:13:24', '::1'),
(35, NULL, 'Nuevo Servicio', 'Servicio', 0, 'Se agrego el servicio \'Pedicure\'.', '2024-09-02 01:15:02', '::1'),
(36, NULL, 'Nuevo Servicio', 'Servicio', 0, 'Se agrego el servicio \'Corte de cabello\'.', '2024-09-02 01:15:53', '::1'),
(37, NULL, 'Nuevo Servicio', 'Servicio', 0, 'Se agrego el servicio \'Tratamiento facial\'.', '2024-09-02 01:16:24', '::1'),
(38, NULL, 'Nueva Venta', 'Ventas', 25, 'Se agrego una venta por el valor de: \'52.9\'.', '2024-09-02 02:05:46', '::1'),
(39, NULL, 'Nueva Venta', 'Ventas', 26, 'Se agrego una venta por el valor de: \'8.45\'.', '2024-09-02 03:11:40', '::1'),
(40, NULL, 'Nueva Venta', 'Ventas', 27, 'Se agrego una venta por el valor de: \'2.88\'.', '2024-09-02 03:18:17', '::1'),
(41, NULL, 'Nueva Venta', 'Ventas', 28, 'Se agrego una venta por el valor de: \'5.75\'.', '2024-09-02 03:22:11', '::1'),
(42, NULL, 'Nueva Venta', 'Ventas', 29, 'Se agrego una venta por el valor de: \'5.75\'.', '2024-09-02 03:23:00', '::1'),
(43, NULL, 'Nueva Venta', 'Ventas', 30, 'Se agrego una venta por el valor de: \'5.75\'.', '2024-09-02 03:23:34', '::1'),
(44, NULL, 'Nueva Venta', 'Ventas', 31, 'Se agrego una venta por el valor de: \'17.25\'.', '2024-09-02 03:26:22', '::1'),
(45, NULL, 'Nueva Venta', 'Ventas', 32, 'Se agrego una venta por el valor de: \'11.5\'.', '2024-09-02 03:27:17', '::1'),
(46, NULL, 'Nueva Venta', 'Ventas', 33, 'Se agrego una venta por el valor de: \'13.8\'.', '2024-09-02 03:27:57', '::1'),
(47, NULL, 'Nueva Venta', 'Ventas', 34, 'Se agrego una venta por el valor de: \'11.5\'.', '2024-09-02 03:29:50', '::1'),
(48, NULL, 'Nueva Venta', 'Ventas', 35, 'Se agrego una venta por el valor de: \'9.2\'.', '2024-09-02 03:31:03', '::1'),
(49, NULL, 'Nueva Venta', 'Ventas', 36, 'Se agrego una venta por el valor de: \'5.75\'.', '2024-09-02 03:43:23', '::1'),
(50, NULL, 'Nueva Venta', 'Ventas', 37, 'Se agrego una venta por el valor de: \'5.75\'.', '2024-09-02 03:46:18', '::1'),
(51, NULL, 'Nueva Venta', 'Ventas', 38, 'Se agrego una venta por el valor de: \'31.05\'.', '2024-09-02 03:50:36', '::1'),
(52, NULL, 'Nueva Venta', 'Ventas', 39, 'Se agrego una venta por el valor de: \'21.85\'.', '2024-09-02 03:53:29', '::1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `spa_servicios`
--

CREATE TABLE `spa_servicios` (
  `id_servicio` int(100) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `descripcion` varchar(123) NOT NULL,
  `productos` varchar(213) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `precio` float NOT NULL,
  `estado` varchar(10) NOT NULL DEFAULT 'activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `spa_servicios`
--

INSERT INTO `spa_servicios` (`id_servicio`, `nombre`, `descripcion`, `productos`, `precio`, `estado`) VALUES
(41, 'Pedicure', 'Tratamiento de uñas', '[\"46\"]', 12, 'activo'),
(42, 'Corte de cabello', 'Cortar pelo a gusto del cliente', '[\"50\"]', 5, 'activo'),
(43, 'Tratamiento facial', 'Tratamiento para las arrugas', '[\"47\"]', 9, 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `spa_usuarios`
--

CREATE TABLE `spa_usuarios` (
  `id_usuario` int(100) NOT NULL,
  `nombre_usuario` varchar(20) NOT NULL,
  `correo` varchar(30) NOT NULL,
  `telefono` varchar(10) NOT NULL,
  `tipo_perfil` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `cedula` varchar(10) NOT NULL,
  `user` varchar(121) NOT NULL,
  `contrasena` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `estado` varchar(12) NOT NULL DEFAULT 'activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `spa_usuarios`
--

INSERT INTO `spa_usuarios` (`id_usuario`, `nombre_usuario`, `correo`, `telefono`, `tipo_perfil`, `cedula`, `user`, `contrasena`, `fecha_registro`, `estado`) VALUES
(1, 'jefferson', 'jjj@gmail.com', '0999945031', 'administrador', '1234567891', 'admin', 'admin', '2024-08-22 00:00:00', 'activo'),
(54, 'justin', 'jjj@gmail.com', '0944444444', 'Bodegero', '1545564879', 'bodega', 'bodega', '2024-08-31 16:00:18', 'activo'),
(55, 'alejandro', 'as@gmail.com', '4565465456', 'Ventas', '1234567891', 'venta', 'venta', '2024-08-31 16:00:57', 'activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `spa_categorias`
--
ALTER TABLE `spa_categorias`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indices de la tabla `spa_clientes`
--
ALTER TABLE `spa_clientes`
  ADD PRIMARY KEY (`id_cliente`),
  ADD UNIQUE KEY `cedula` (`cedula`);

--
-- Indices de la tabla `spa_facturas`
--
ALTER TABLE `spa_facturas`
  ADD PRIMARY KEY (`Id_factura`);

--
-- Indices de la tabla `spa_modulos`
--
ALTER TABLE `spa_modulos`
  ADD PRIMARY KEY (`id_modulos`);

--
-- Indices de la tabla `spa_perfiles`
--
ALTER TABLE `spa_perfiles`
  ADD PRIMARY KEY (`id_perfil`),
  ADD UNIQUE KEY `perfil` (`perfil`);

--
-- Indices de la tabla `spa_productos`
--
ALTER TABLE `spa_productos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo_producto` (`codigo_producto`);

--
-- Indices de la tabla `spa_reportes`
--
ALTER TABLE `spa_reportes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `spa_servicios`
--
ALTER TABLE `spa_servicios`
  ADD PRIMARY KEY (`id_servicio`);

--
-- Indices de la tabla `spa_usuarios`
--
ALTER TABLE `spa_usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `spa_categorias`
--
ALTER TABLE `spa_categorias`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `spa_clientes`
--
ALTER TABLE `spa_clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `spa_facturas`
--
ALTER TABLE `spa_facturas`
  MODIFY `Id_factura` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT de la tabla `spa_modulos`
--
ALTER TABLE `spa_modulos`
  MODIFY `id_modulos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=225;

--
-- AUTO_INCREMENT de la tabla `spa_perfiles`
--
ALTER TABLE `spa_perfiles`
  MODIFY `id_perfil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT de la tabla `spa_productos`
--
ALTER TABLE `spa_productos`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT de la tabla `spa_reportes`
--
ALTER TABLE `spa_reportes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT de la tabla `spa_servicios`
--
ALTER TABLE `spa_servicios`
  MODIFY `id_servicio` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT de la tabla `spa_usuarios`
--
ALTER TABLE `spa_usuarios`
  MODIFY `id_usuario` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
