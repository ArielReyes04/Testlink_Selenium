<?php
session_start(); // Inicia la sesión

date_default_timezone_set('America/Guayaquil');
$username = "root";
$password = "";
$dbname = "aura spa";
$servername = "localhost";

// Conexión a la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

function registrarCambio($conn, $usuario, $tipo_cambio, $entidad, $id_entidad, $descripcion) {
    $fecha_hora = date('Y-m-d H:i:s');
    $ip_usuario = $_SERVER['REMOTE_ADDR'];
    
    $sql = "INSERT INTO spa_reportes (usuario, tipo_cambio, entidad, id_entidad, descripcion, fecha_hora, ip_usuario)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $usuario, $tipo_cambio, $entidad, $id_entidad, $descripcion, $fecha_hora, $ip_usuario);
    if (!$stmt->execute()) {
        error_log("Error al registrar cambio: " . $stmt->error); // Registrar el error en el log
    }
    $stmt->close(); // Cierra el statement después de ejecutarlo
}

$message = ""; // Variable para almacenar mensajes

// Inicializar datos del formulario
$nombre_servicio = "";
$descripcion = "";
$precio = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_servicio'])) {
    $id_servicio = $_POST['id_servicio_hidden'] ?? null; // ID del servicio si se está editando
    $nombre_servicio = $_POST['nombre_servicio'];
    $descripcion = $_POST['descripcion'];
    $productos = $_POST['productos_hidden']; // Productos seleccionados como IDs
    $precio = $_POST['precio'];

    // Convertir la cadena de productos a una lista (array)
    $productos_array = explode(',', $productos);
    $productos_json = json_encode($productos_array); // Convertir a formato JSON

    if ($id_servicio) {
        // Actualizar servicio existente
        $sql = "UPDATE spa_servicios SET nombre = ?, descripcion = ?, precio = ?, productos = ? WHERE id_servicio = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssisi", $nombre_servicio, $descripcion, $precio, $productos_json, $id_servicio);
		$usuario = $_SESSION['usuario'];
        $id_entidad = $id_servicio;
        $tipo_cambio = "Actualizar Servicio";
        $descripcion_reporte = "Se actualizo el servicio '$nombre_servicio' con código '$id_servicio'.";

        registrarCambio($conn, $usuario, $tipo_cambio, "Servicio", $id_entidad, $descripcion_reporte);
    } else {
        // Insertar nuevo servicio
        $sql = "INSERT INTO spa_servicios (nombre, descripcion, precio, productos) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssis", $nombre_servicio, $descripcion, $precio, $productos_json);
		$usuario = $_SESSION['usuario'];
        $id_entidad = $conn->insert_id;
        $tipo_cambio = "Nuevo Servicio";
        $descripcion_reporte = "Se agrego el servicio '$nombre_servicio'.";

        registrarCambio($conn, $usuario, $tipo_cambio, "Servicio", $id_entidad, $descripcion_reporte);
    }

    if ($stmt->execute()) {
        // Vaciar la lista de productos en localStorage
        echo "<script>
                localStorage.removeItem('productos_agregados');
                localStorage.removeItem('nombre_servicio');
                localStorage.removeItem('descripcion');
                localStorage.removeItem('precio');
                document.getElementById('formulario').reset();
                document.getElementById('lista_productos').innerHTML = '';
                alert('Servicio guardado exitosamente');
              </script>";

        $message = "Servicio guardado exitosamente";
    } else {
        $message = "Error al guardar servicio: " . $stmt->error;
    }
}

// Obtener categorías para el select
$categorias_sql = "SELECT DISTINCT categoria FROM spa_productos";
$categorias_result = $conn->query($categorias_sql);

if ($categorias_result === FALSE) {
    die("Error al obtener categorías: " . $conn->error);
}

// Obtener servicios existentes
$servicios_sql = "SELECT * FROM spa_servicios";
$servicios_result = $conn->query($servicios_sql);

if ($servicios_result === FALSE) {
    die("Error al obtener servicios: " . $conn->error);
}

// Manejo de AJAX para cargar productos según la categoría seleccionada
if (isset($_GET['action']) && $_GET['action'] == 'cargar_productos') {
    $categoria = $_GET['categoria'];
    $productos_sql = "SELECT id, nombre_producto FROM spa_productos WHERE categoria = ?";
    $stmt = $conn->prepare($productos_sql);
    $stmt->bind_param("s", $categoria);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        $productos = [];
        while ($prod = $result->fetch_assoc()) {
            $productos[] = $prod;
        }
        echo json_encode($productos);
    } else {
        echo json_encode(['error' => $stmt->error]);
    }
    exit; // Terminar el script después de la respuesta AJAX
}


if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['action']) && $_GET['action'] == 'obtener_servicio' && isset($_GET['id_servicio'])) {
    $id_servicio = intval($_GET['id_servicio']);
    $sql = "SELECT * FROM spa_servicios WHERE id_servicio = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_servicio);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        $servicio = $result->fetch_assoc();
        $servicio['productos'] = json_decode($servicio['productos'], true);

        // Obtener nombres de productos
        $productos_nombres = [];
        if (!empty($servicio['productos'])) {
            $productos_ids = implode(',', array_map('intval', $servicio['productos']));
            $productos_sql = "SELECT id, nombre_producto FROM spa_productos WHERE id IN ($productos_ids)";
            $productos_result = $conn->query($productos_sql);
            if ($productos_result) {
                while ($producto = $productos_result->fetch_assoc()) {
                    $productos_nombres[$producto['id']] = $producto['nombre_producto'];
                }
            }
        }

        $servicio['productos_nombres'] = $productos_nombres;
        echo json_encode($servicio);
    } else {
        echo json_encode(['error' => $stmt->error]);
    }
    exit;
}

// Manejo de AJAX para cambiar el estado del servicio
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'cambiar_estado') {
    $id_servicio = intval($_POST['id_servicio']);
    $nuevo_estado = $_POST['nuevo_estado'];

    $sql = "UPDATE spa_servicios SET estado = ? WHERE id_servicio = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $nuevo_estado, $id_servicio);

    if ($stmt->execute()) {
		$usuario = $_SESSION['usuario'];
        $id_entidad = $id_servicio;
        $tipo_cambio = "Cambio Estado Servicio";
        $descripcion_reporte = "Se actualizo el estado del servicio '$nombre_servicio' a '$nuevo_estado'.";

        registrarCambio($conn, $usuario, $tipo_cambio, "Servicio", $id_entidad, $descripcion_reporte);
        echo "Estado actualizado exitosamente";
    } else {
        echo "Error al actualizar el estado: " . $stmt->error;
    }
    exit;
}

$conn->close();
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Gestión de Servicios</title>
    <link href="../css/estilo_Servicios.css" rel="stylesheet" type="text/css">
    <link href="../css/estilo_Pagina.css" rel="stylesheet" type="text/css">
    <script src="../js/servicios.js" defer></script>
</head>
<body>
    <?php include 'barra_navegacion.php'; ?>

    <h1>Gestión de Servicios</h1>

    <!-- Botón para abrir el modal -->
<button id="agregar-servicio" onclick="mostrarModal()">Agregar Servicio</button>

    <!-- Mensajes de éxito o error -->
    <?php if (!empty($message)) { ?>
        <div class="message"><?php echo $message; ?></div>
    <?php } ?>

    <!-- Modal para el formulario -->
    <div id="modal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="cerrarModal()">&times;</span>
            <h2>Agregar Nuevo Servicio</h2>
<form id="formulario" action="servicios.php" method="post" onsubmit="return guardarDatosAntesDeEnviar() && validarFormulario()">
                <label for="nombre_servicio">Nombre del Servicio:</label>
                <input type="text" id="nombre_servicio" name="nombre_servicio" required><br>
    <div id="error_nombre_servicio" class="error"></div><br>
                <label for="descripcion">Descripción:</label>
                <textarea id="descripcion" name="descripcion" required></textarea><br>
    <div id="error_descripcion" class="error"></div><br>
                <label for="categoria">Categoría:</label>
                <select id="categoria" name="categoria" onchange="cargarProductosAJAX(this.value)">
                    <option value="">Seleccione una categoría</option>
                    <?php while ($cat = $categorias_result->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($cat['categoria']); ?>" <?php if (isset($_GET['categoria']) && $_GET['categoria'] == $cat['categoria']) echo 'selected'; ?>>
                            <?php echo htmlspecialchars($cat['categoria']); ?>
                        </option>
                    <?php endwhile; ?>
                </select><br>
    <div id="error_categoria" class="error"></div><br>
                <label for="productos">Productos:</label>
                <select id="productos" name="productos[]" multiple></select>
                <button type="button" onclick="agregarProducto()">Agregar Productos Seleccionados</button><br>
    <div id="error_productos" class="error"></div><br>
                <label>Productos Agregados:</label>
                <ul id="lista_productos"></ul>

                <input type="hidden" id="productos_hidden" name="productos_hidden">
                <input type="hidden" id="id_servicio_hidden" name="id_servicio_hidden"> <!-- Campo oculto para ID del servicio -->

                <label for="precio">Precio:</label>
                <input type="number" id="precio" name="precio" step="0.01" required><br>
    <div id="error_precio" class="error"></div><br>
                <button type="submit" name="guardar_servicio">Guardar Servicio</button>
            </form>
        </div>
    </div>

    <!-- Tabla de servicios existentes -->
    <h2>Servicios Existentes</h2>
    <table>
        <thead>
            <tr>
                <th>ID Servicio</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Productos</th>
                <th>Precio</th>
                <th>Estado</th>
                <th>Acciones</th> <!-- Nueva columna para acciones -->
            </tr>
        </thead>
        <tbody>
            <?php while ($servicio = $servicios_result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($servicio['id_servicio']); ?></td>
                    <td><?php echo htmlspecialchars($servicio['nombre']); ?></td>
                    <td><?php echo htmlspecialchars($servicio['descripcion']); ?></td>
                     <td>
                        <?php
						 
						 $conn = new mysqli($servername, $username, $password, $dbname);
                        if (isset($servicio['productos'])) {
                            $productos_servicio = json_decode($servicio['productos'], true);
                            if ($productos_servicio && is_array($productos_servicio) && !empty($productos_servicio)) {
                                $productos_ids = implode(',', array_map('intval', $productos_servicio));
                                $producto_sql = "SELECT nombre_producto FROM spa_productos WHERE id IN ($productos_ids)";
                                $producto_result = $conn->query($producto_sql);
                                if ($producto_result) {
                                    $productos_nombres = [];
                                    while ($producto = $producto_result->fetch_assoc()) {
                                        $productos_nombres[] = htmlspecialchars($producto['nombre_producto']);
                                    }
                                    echo !empty($productos_nombres) ? implode(', ', $productos_nombres) : "No se encontraron productos.";
                                } else {
                                    echo "Error al ejecutar la consulta: " . $conn->error;
                                }
                            } else {
                                echo "No hay productos para mostrar.";
                            }
                        } else {
                            echo "El campo 'productos' no está definido en el servicio.";
                        }
                        ?>
                    </td>


                    <td><?php echo htmlspecialchars($servicio['precio']); ?></td>
                    <td><?php echo htmlspecialchars($servicio['estado']); ?></td>
                    <td>
                        <button class="editar" onclick="editarServicio(<?php echo $servicio['id_servicio']; ?>)">Editar</button>
                        <button class="<?php echo $servicio['estado'] == 'activo' ? 'inactivar' : 'activar'; ?>"
        onclick="cambiarEstado(<?php echo $servicio['id_servicio']; ?>, '<?php echo $servicio['estado']; ?>')">
    <?php echo $servicio['estado'] == 'activo' ? 'Inactivar' : 'Activar'; ?>
</button>

                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>