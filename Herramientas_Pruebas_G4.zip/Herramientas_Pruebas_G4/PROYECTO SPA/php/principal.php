<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user'])) {
    header("Location: iniciarseccion.php");
    exit();
}

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aura spa";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el tipo de perfil del usuario desde la sesión
$tipo_perfil = $_SESSION['tipo_perfil'];
$user = $_SESSION['user']; // Nombre de usuario para la sesión

// Obtener todos los datos del usuario
$sql = "SELECT nombre_usuario, correo, telefono, tipo_perfil, cedula, user
        FROM spa_usuarios WHERE user = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error en la preparación de la consulta: " . $conn->error);
}

$stmt->bind_param("s", $user);
$stmt->execute();
$result = $stmt->get_result();

$usuario_info = null; // Valor por defecto

if ($result->num_rows > 0) {
    $usuario_info = $result->fetch_assoc();
} else {
    // Manejo en caso de que no se encuentre el usuario
    $usuario_info = [
        'nombre_usuario' => 'No encontrado',
        'correo' => 'No encontrado',
        'telefono' => 'No encontrado',
        'tipo_perfil' => 'No encontrado',
        'cedula' => 'No encontrado',
        'user' => 'No encontrado',
    ];
}

// Obtener los módulos disponibles para el tipo de perfil del usuario
$sql_modulos = "SELECT modulo FROM spa_modulos WHERE FIND_IN_SET(?, modulo)";
$stmt_modulos = $conn->prepare($sql_modulos);

if (!$stmt_modulos) {
    die("Error en la preparación de la consulta de módulos: " . $conn->error);
}

$stmt_modulos->bind_param("s", $tipo_perfil);
$stmt_modulos->execute();
$result_modulos = $stmt_modulos->get_result();

$modulos = [];

while ($row = $result_modulos->fetch_assoc()) {
    $modulos[] = $row['modulo'];
}

$stmt_modulos->close();
$conn->close();
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Panel Principal</title>
    <link href="../css/estilo_Pagina.css" rel="stylesheet" type="text/css">
</head>
<body>

    <!-- Incluir la barra de navegación -->
    <?php include 'barra_navegacion.php'; ?>

    <!-- Contenido principal -->
    <div class="contenidoprincipal">
        <h1>Bienvenido, <?php echo htmlspecialchars($usuario_info['nombre_usuario']); ?>!</h1>
        <p>Aquí puedes gestionar los módulos disponibles según tu perfil.</p>

        <!-- Sección de información importante -->
        <section class="informacion-importante">
            <h2>Información del Usuario</h2>
            <ul>
                <li><strong>Usuario:</strong> <?php echo htmlspecialchars($usuario_info['user']); ?></li>
                <li><strong>Nombre de Usuario:</strong> <?php echo htmlspecialchars($usuario_info['nombre_usuario']); ?></li>
                <li><strong>Correo:</strong> <?php echo htmlspecialchars($usuario_info['correo']); ?></li>
                <li><strong>Teléfono:</strong> <?php echo htmlspecialchars($usuario_info['telefono']); ?></li>
                <li><strong>Perfil:</strong> <?php echo htmlspecialchars($usuario_info['tipo_perfil']); ?></li>
                <li><strong>Cédula:</strong> <?php echo htmlspecialchars($usuario_info['cedula']); ?></li>
            </ul>
        </section>

        <!-- Sección de módulos disponibles -->
        <section class="modulos-disponibles">
            <h2>Módulos Disponibles</h2>
            <ul>
                <?php foreach ($modulos as $modulo): ?>
                    <li><?php echo htmlspecialchars($modulo); ?></li>
                <?php endforeach; ?>
            </ul>
        </section>
    </div>
</body>
</html>
