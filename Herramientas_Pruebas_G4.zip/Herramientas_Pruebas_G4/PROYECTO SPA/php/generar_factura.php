<?php
// Configuración de la zona horaria
date_default_timezone_set('America/Guayaquil');

// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aura spa";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el último ID de factura
$sql = "SELECT id_factura FROM spa_facturas ORDER BY id_factura DESC LIMIT 1";
$result = $conn->query($sql);
$response = array('id_factura' => null);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $response['id_factura'] = $row['id_factura'];
} else {
    die("No se pudo obtener el ID de la última factura.");
}

$factura_id = $response['id_factura'];

// Recuperar datos de la factura
$sql = "SELECT Id_Factura, cedula_cliente, cedula_vendedor, fecha_emision, productos_id_cantida, total_sin_iva, iva, valor_total
        FROM spa_facturas
        WHERE Id_Factura = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $factura_id);
$stmt->execute();
$result = $stmt->get_result();
$factura = $result->fetch_assoc();

// Verificar que se obtuvieron datos
if (!$factura) {
    die("Factura no encontrada. ID de factura: " . htmlspecialchars($factura_id));
}

// Recuperar datos del cliente
$cedula_cliente = $factura['cedula_cliente'];
$sqlCliente = "SELECT id_cliente, nombres, telefono, direccion, email, fnac, estado
               FROM spa_clientes
               WHERE cedula = ?";
$stmtCliente = $conn->prepare($sqlCliente);
$stmtCliente->bind_param("s", $cedula_cliente);
$stmtCliente->execute();
$resultCliente = $stmtCliente->get_result();
$cliente = $resultCliente->fetch_assoc();

// Verificar que se obtuvieron datos del cliente
if (!$cliente) {
    die("Cliente no encontrado.");
}

// Datos de la empresa
$datosEmpresa = [
    'Nombre' => 'AURA SPA',
    'RUC' => '05082019011600312001002000200000837477040611',
    'DireccionMatriz' => 'AV. MARISCAL SUCRE Y CALLE B',
    'DireccionSucursal' => 'AV. GONZALEZ SUAREZ Y CESLAO MARIN',
    'Telefono' => '+593 999945031',
    'Email' => 'contacto@auraspa.com',
    'SitioWeb' => 'www.auraspa.com',
    'Logo' => '../img/logo.png' // Ruta al logo
];

// Definir el directorio de destino
$directorioDestino = '../facturas_xml/'; // Cambia esta ruta a la dirección deseada
if (!is_dir($directorioDestino)) {
    mkdir($directorioDestino, 0777, true);
}

// Crear un nuevo documento PDF
require_once('../fpdf/fpdf.php');

$pdf = new FPDF();
$pdf->AddPage();

// Agregar logo
if (file_exists($datosEmpresa['Logo'])) {
    $pdf->Image($datosEmpresa['Logo'], 10, 10, 30);
}
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 5, $datosEmpresa['Nombre'], 0, 1, 'C');
$pdf->SetFont('Arial', 'I', 12);
$pdf->Cell(0, 5, 'RUC: ' . $datosEmpresa['RUC'], 0, 1, 'C');
$pdf->Cell(0, 5, 'Direccion Matriz: ' . $datosEmpresa['DireccionMatriz'], 0, 1, 'C');
$pdf->Cell(0, 5, 'Direccion Sucursal: ' . $datosEmpresa['DireccionSucursal'], 0, 1, 'C');
$pdf->Cell(0, 5, 'Telefono: ' . $datosEmpresa['Telefono'], 0, 1, 'C');
$pdf->Cell(0, 5, 'Email: ' . $datosEmpresa['Email'], 0, 1, 'C');
$pdf->Cell(0, 5, 'Sitio Web: ' . $datosEmpresa['SitioWeb'], 0, 1, 'C');
$pdf->Ln(10);

// Datos del cliente y datos de la factura en columnas
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(90, 5, 'Datos del Cliente', 1);
$pdf->Cell(90, 5, 'Datos de la Factura', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 10);
$pdf->Cell(90, 10, 'ID Cliente: ' . $cliente['id_cliente'], 0);
$pdf->Cell(90, 10, 'ID Factura: ' . $factura['Id_Factura'], 0);
$pdf->Ln();
$pdf->Cell(90, 10, 'Nombres: ' . $cliente['nombres'], 0);
$pdf->Cell(90, 10, 'Cedula Cliente: ' . $factura['cedula_cliente'], 0);
$pdf->Ln();
$pdf->Cell(90, 10, 'Telefono: ' . $cliente['telefono'], 0);
$pdf->Cell(90, 10, 'Cedula Vendedor: ' . $factura['cedula_vendedor'], 0);
$pdf->Ln();
$pdf->Cell(90, 10, 'Direccion: ' . $cliente['direccion'], 0);
$pdf->Cell(90, 10, 'Fecha de Emision: ' . $factura['fecha_emision'], 0);
$pdf->Ln();
$pdf->Cell(90, 10, 'Email: ' . $cliente['email'], 0);
$pdf->Ln();

// Agregar detalles de productos
$pdf->Ln();
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(40, 10, 'Codigo', 1);
$pdf->Cell(60, 10, 'Nombre Producto', 1);
$pdf->Cell(25, 10, 'Cantidad', 1);
$pdf->Cell(35, 10, 'Precio Unitario', 1);
$pdf->Cell(30, 10, 'Total', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 10);
$precioTotal = 0;
$productos = json_decode($factura['productos_id_cantida'], true);

if (is_array($productos)) {
    foreach ($productos as $producto) {
        $codigoProducto = isset($producto['codigo']) ? $producto['codigo'] : 'Desconocido'; // Manejar índice no definido

        // Buscar en la tabla de productos
        $sqlProducto = "SELECT nombre_producto, precio_unitario FROM spa_productos WHERE codigo_producto = ?";
        $stmtProducto = $conn->prepare($sqlProducto);
        $stmtProducto->bind_param("s", $codigoProducto);
        $stmtProducto->execute();
        $resultProducto = $stmtProducto->get_result();
        $productoData = $resultProducto->fetch_assoc();

        if ($productoData) {
            $nombreProducto = $productoData['nombre_producto'];
            $precioProducto = $productoData['precio_unitario'];
        } else {
            // Buscar en la tabla de servicios si no se encuentra en productos
            $sqlServicio = "SELECT nombre, precio FROM spa_servicios WHERE id_servicio = ?";
            $stmtServicio = $conn->prepare($sqlServicio);
            $stmtServicio->bind_param("i", $codigoProducto); // Usar tipo "i" para enteros
            $stmtServicio->execute();
            $resultServicio = $stmtServicio->get_result();
            $servicioData = $resultServicio->fetch_assoc();
            $nombreProducto = $servicioData ? $servicioData['nombre'] : 'Desconocido';
            $precioProducto = $servicioData ? $servicioData['precio'] : 0;
        }

        $cantidad = isset($producto['cantidad']) ? $producto['cantidad'] : '0';
        $totalProducto = $precioProducto * $cantidad;
        $precioTotal += $totalProducto;

        $pdf->Cell(40, 10, $codigoProducto, 1);
        $pdf->Cell(60, 10, $nombreProducto, 1);
        $pdf->Cell(25, 10, $cantidad, 1);
        $pdf->Cell(35, 10, number_format($precioProducto, 2), 1);
        $pdf->Cell(30, 10, number_format($totalProducto, 2), 1);
        $pdf->Ln();
    }
}

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(160, 10, 'Total Sin IVA', 1);
$pdf->Cell(30, 10, number_format($factura['total_sin_iva'], 2), 1);
$pdf->Ln();
$pdf->Cell(160, 10, 'IVA', 1);
$pdf->Cell(30, 10, number_format($factura['iva'], 2), 1);
$pdf->Ln();
$pdf->Cell(160, 10, 'Valor Total', 1);
$pdf->Cell(30, 10, number_format($factura['valor_total'], 2), 1);
$pdf->Ln();

$pdf->SetFont('Arial', 'I', 10);
$pdf->Cell(0, 10, 'Gracias por su compra!', 0, 1, 'C');
$pdf->Cell(0, 10, 'Este documento es una factura de venta.', 0, 1, 'C');

// Generar el archivo PDF en el directorio específico
$pdfOutput = $directorioDestino . 'Factura_' . $factura_id . '.pdf';
$pdf->Output('F', $pdfOutput);

// Crear el archivo XML
$xml = new SimpleXMLElement('<Factura/>');
$xml->addChild('Id_Factura', $factura['Id_Factura']);
$xml->addChild('Cedula_Cliente', $factura['cedula_cliente']);
$xml->addChild('Cedula_Vendedor', $factura['cedula_vendedor']);
$xml->addChild('Fecha_Emision', $factura['fecha_emision']);
$xml->addChild('Total_Sin_Iva', $factura['total_sin_iva']);
$xml->addChild('IVA', $factura['iva']);
$xml->addChild('Valor_Total', $factura['valor_total']);

$productosXML = $xml->addChild('Productos');
$productos = json_decode($factura['productos_id_cantida'], true);
if (is_array($productos)) {
    foreach ($productos as $producto) {
        $productoXML = $productosXML->addChild('Producto');
        $productoXML->addChild('Codigo', $producto['codigo']);
        $productoXML->addChild('Cantidad', $producto['cantidad']);
        // Buscar en la tabla de productos
        $sqlProducto = "SELECT nombre_producto, precio_unitario FROM spa_productos WHERE codigo_producto = ?";
        $stmtProducto = $conn->prepare($sqlProducto);
        $stmtProducto->bind_param("s", $producto['codigo']);
        $stmtProducto->execute();
        $resultProducto = $stmtProducto->get_result();
        $productoData = $resultProducto->fetch_assoc();
        
        if ($productoData) {
            $productoXML->addChild('Nombre', $productoData['nombre_producto']);
            $productoXML->addChild('Precio_Unitario', $productoData['precio_unitario']);
        } else {
            // Buscar en la tabla de servicios si no se encuentra en productos
            $sqlServicio = "SELECT nombre, precio FROM spa_servicios WHERE id_servicio = ?";
            $stmtServicio = $conn->prepare($sqlServicio);
            $stmtServicio->bind_param("i", $producto['codigo']); // Usar tipo "i" para enteros
            $stmtServicio->execute();
            $resultServicio = $stmtServicio->get_result();
            $servicioData = $resultServicio->fetch_assoc();
            $productoXML->addChild('Nombre', $servicioData ? $servicioData['nombre'] : 'Desconocido');
            $productoXML->addChild('Precio_Unitario', $servicioData ? $servicioData['precio'] : '0');
        }
    }
}

// Guardar el archivo XML en el directorio específico
$xmlOutput = $directorioDestino . 'Factura_' . $factura_id . '.xml';
$xml->asXML($xmlOutput);

// Cerrar la conexión a la base de datos
$conn->close();

// Mensaje de confirmación
echo "<script>alert('La factura ha sido generada exitosamente.'); window.location.href = 'generar_factura.php';</script>";
?>
