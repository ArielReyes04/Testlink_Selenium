<?php
session_start();
date_default_timezone_set('America/Guayaquil');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aura spa";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Función para registrar los cambios
function registrarCambio($conn, $usuario, $tipo_cambio, $entidad, $id_entidad, $descripcion) {
    $fecha_hora = date('Y-m-d H:i:s');
    $ip_usuario = $_SERVER['REMOTE_ADDR'];
    
    $sql = "INSERT INTO spa_reportes (usuario, tipo_cambio, entidad, id_entidad, descripcion, fecha_hora, ip_usuario)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $usuario, $tipo_cambio, $entidad, $id_entidad, $descripcion, $fecha_hora, $ip_usuario);
    if (!$stmt->execute()) {
        error_log("Error al registrar cambio: " . $stmt->error); // Registrar el error en el log
    }
    $stmt->close(); // Cierra el statement después de ejecutarlo
}

$message = "";

// Insertar o actualizar cliente
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['guardar'])) {
        $nombres = $_POST['nombres'];
        $cedula = $_POST['cedula'];
        $telefono = $_POST['telefono'];
        $direccion = $_POST['direccion'];
        $email = $_POST['email'];
        $fnac = $_POST['fnac'];
        
        if (isset($_POST['id_cliente']) && !empty($_POST['id_cliente'])) {
            // Actualizar cliente existente
            $id_cliente = $_POST['id_cliente'];

            $sql = "UPDATE spa_clientes SET nombres=?, cedula=?, telefono=?, direccion=?, email=?, fnac=? WHERE id_cliente=?";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssi", $nombres, $cedula, $telefono, $direccion, $email, $fnac, $id_cliente);
            
            if ($stmt->execute()) {
                $usuario = $_SESSION['usuario'];
                $id_entidad = $id_cliente;
                $tipo_cambio = "Actualización Cliente";
                $descripcion_reporte = "Se actualizó el cliente '$nombres' con correo '$email'.";
                registrarCambio($conn, $usuario, $tipo_cambio, "Cliente", $id_entidad, $descripcion_reporte);
                $message = "Cliente actualizado exitosamente";
            } else {
                $message = "Error al actualizar cliente: " . $stmt->error;
            }
            $stmt->close();
        } else {
            // Insertar nuevo cliente
            $sql = "INSERT INTO spa_clientes (nombres, cedula, telefono, direccion, email, fnac)
                    VALUES (?, ?, ?, ?, ?, ?)";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssss", $nombres, $cedula, $telefono, $direccion, $email, $fnac);
            
            if ($stmt->execute()) {
                $usuario = $_SESSION['usuario'];
                $id_entidad = $conn->insert_id;
                $tipo_cambio = "Nuevo Cliente";
                $descripcion_reporte = "Se creó el cliente '$nombres' con correo '$email'.";

                registrarCambio($conn, $usuario, $tipo_cambio, "Cliente", $id_entidad, $descripcion_reporte);
                
                $message = "Nuevo cliente creado exitosamente";
            } else {
                $message = "Error al crear cliente: " . $stmt->error;
            }
            $stmt->close();
        }
    } elseif (isset($_POST['cambiar_estado'])) {
        // Cambiar estado del cliente
        $id_cliente = $_POST['id_cliente'];
        $estado = $_POST['estado'] === 'activo' ? 'inactivo' : 'activo'; // Alterna entre activo e inactivo

        $sql = "UPDATE spa_clientes SET estado=? WHERE id_cliente=?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $estado, $id_cliente);
        
        if ($stmt->execute()) {
            $usuario = $_SESSION['usuario'];
            $tipo_cambio = "Cambio de estado del Cliente: se encuentra '$estado'";
            $descripcion_reporte = "El estado del cliente con ID $id_cliente fue cambiado a '$estado'.";

            registrarCambio($conn, $usuario, $tipo_cambio, "Cliente", $id_cliente, $descripcion_reporte);
            $message = "Estado del cliente actualizado exitosamente";
        } else {
            $message = "Error al actualizar estado: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Obtener clientes
$sql = "SELECT * FROM spa_clientes";
$result = $conn->query($sql);

if ($result === FALSE) {
    $message = "Error en la consulta de clientes: " . $conn->error;
    $clients = [];
} else {
    $clients = $result->fetch_all(MYSQLI_ASSOC);
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Panel de Administrador - Clientes</title>
    <link href="../css/estilo_Pagina.css" rel="stylesheet" type="text/css">
    <link href="../css/estilo_Clientes.css" rel="stylesheet" type="text/css">
    <script src="../js/clientes.js" defer></script>
</head>
<body>
    <!-- Barra de navegación -->
    <?php include 'barra_navegacion.php'; ?>

    <!-- Contenido de la página -->
    <div class="content">
        <h1>Gestión de Clientes</h1>

        <!-- Botón para abrir el modal de agregar cliente -->
        <button id="openModal" class="btn btn-primary">Agregar Cliente</button>
        
        <h2>Lista de Clientes</h2>

        <!-- Modal para agregar/editar clientes -->
        <div id="clientModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h2 id="modalTitle">Agregar Cliente</h2>
                <form action="clientes.php" method="post" id="clientForm">
                    <input type="hidden" name="id_cliente" id="id_cliente" value="">
                    
                    <label for="nombres">Nombres:</label>
                    <input type="text" id="nombres" name="nombres" value="" required><br>
                    
                    <label for="cedula">Cédula:</label>
                    <input type="text" id="cedula" name="cedula" value="" required><br>
                    
                    <label for="telefono">Teléfono:</label>
                    <input type="text" id="telefono" name="telefono" value="" required><br>
                    
                    <label for="direccion">Dirección:</label>
                    <input type="text" id="direccion" name="direccion" value="" required><br>
                    
                    <label for="email">Correo Electrónico:</label>
                    <input type="email" id="email" name="email" value="" required><br>
                    
                    <label for="fnac">Fecha de Nacimiento:</label>
                    <input type="date" id="fnac" name="fnac" value="" required><br>
                    
                    <button type="submit" name="guardar" id="formSubmitButton" class="btn btn-primary">Guardar</button>
                </form>
            </div>
        </div>

        <!-- Tabla de clientes -->
        <div class="tabla">
            <table border="1">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombres</th>
                        <th>Cédula</th>
                        <th>Teléfono</th>
                        <th>Dirección</th>
                        <th>Email</th>
                        <th>Fecha de Nacimiento</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($clients)): ?>
                        <?php foreach ($clients as $row): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['id_cliente']); ?></td>
                                <td><?php echo htmlspecialchars($row['nombres']); ?></td>
                                <td><?php echo htmlspecialchars($row['cedula']); ?></td>
                                <td><?php echo htmlspecialchars($row['telefono']); ?></td>
                                <td><?php echo htmlspecialchars($row['direccion']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['fnac']); ?></td>
                                <td><?php echo htmlspecialchars($row['estado']); ?></td>
                                <td>
                                    <button type="button" class="btn btn-edit" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($row)); ?>)">Editar</button>
                                    <form action="clientes.php" method="post" style="display:inline;">
                                        <input type="hidden" name="id_cliente" value="<?php echo htmlspecialchars($row['id_cliente']); ?>">
                                        <input type="hidden" name="estado" value="<?php echo htmlspecialchars($row['estado']); ?>">
                                        <button type="submit" name="cambiar_estado"><?php echo $row['estado'] === 'activo' ? 'Inactivar' : 'Activar'; ?></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9">No hay clientes registrados.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
<?php
$conn->close();
?>