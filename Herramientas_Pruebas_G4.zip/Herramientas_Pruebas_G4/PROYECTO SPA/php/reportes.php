<?php
session_start();
date_default_timezone_set('America/Guayaquil');

// Conexión a la base de datos
$conn = new mysqli("localhost", "root", "", "aura spa");

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables
$tipo_reporte = '';

// Si se ha enviado un tipo de reporte mediante el formulario, asignar valor
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['filtrar'])) {
    $tipo_reporte = $_POST['tipo_reporte'];
}

// Filtrar por tipo de entidad (e.g., Cliente, Servicio, Producto)
$sql = "SELECT * FROM spa_reportes WHERE entidad LIKE ? ORDER BY fecha_hora DESC";
$stmt = $conn->prepare($sql);
$search_term = ($tipo_reporte === '') ? '%' : $tipo_reporte;
$stmt->bind_param("s", $search_term);
$stmt->execute();
$resultado = $stmt->get_result();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Reporte de Cambios</title>
    <link href="../css/estilo_Pagina.css" rel="stylesheet" type="text/css">
    <style>
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
    </style>
</head>
<body>
    <h1>Reporte de Cambios</h1>
    <?php include 'barra_navegacion.php'; ?>
   <form action="reporte.php" method="post">
        <label for="tipo_reporte">Filtrar por:</label>
        <select name="tipo_reporte" id="tipo_reporte">
            <option value="">Todos</option>
            <option value="Cliente" <?php echo $tipo_reporte === 'Cliente' ? 'selected' : ''; ?>>Clientes</option>
            <option value="Bodega" <?php echo $tipo_reporte === 'Bodega' ? 'selected' : ''; ?>>Bodega</option>
            <option value="Servicio" <?php echo $tipo_reporte === 'Servicio' ? 'selected' : ''; ?>>Servicios</option>
        </select>
        <button type="submit" name="filtrar">Filtrar</button>
    </form>
 
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Usuario</th>
                <th>Tipo de Cambio</th>
                <th>Entidad</th>
                <th>ID Entidad</th>
                <th>Descripción</th>
                <th>Fecha y Hora</th>
                <th>IP del Usuario</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $resultado->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['id']); ?></td>
                <td><?php echo htmlspecialchars($row['usuario']); ?></td>
                <td><?php echo htmlspecialchars($row['tipo_cambio']); ?></td>
                <td><?php echo htmlspecialchars($row['entidad']); ?></td>
                <td><?php echo htmlspecialchars($row['id_entidad']); ?></td>
                <td><?php echo htmlspecialchars($row['descripcion']); ?></td>
                <td><?php echo htmlspecialchars($row['fecha_hora']); ?></td>
                <td><?php echo htmlspecialchars($row['ip_usuario']); ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>