<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Gestión de Perfiles</title>
    <link rel="stylesheet" type="text/css" href="../css/estilo_Perfiles.css">
    <link rel="stylesheet" type="text/css" href="../css/estilo_Pagina.css">
</head>

<body>
<?php
session_start();
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aura spa";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Procesar los botones de activar, inactivar y editar
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    $id_perfil = $_GET['id_perfil'];

    if ($action == 'activar') {
        $sql = "UPDATE spa_perfiles SET estado='activo' WHERE id_perfil=?";
    } elseif ($action == 'inactivar') {
        $sql = "UPDATE spa_perfiles SET estado='inactivo' WHERE id_perfil=?";
    } elseif ($action == 'editar') {
        $sql = "SELECT * FROM spa_perfiles WHERE id_perfil=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id_perfil);
        $stmt->execute();
        $perfil = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        // Verificar que se obtuvo el perfil
        if ($perfil) {
            // Imprimir los datos en formato HTML
            echo "<div id='perfil_data' data-id='" . htmlspecialchars($perfil['id_perfil']) . "'"
                . " data-perfil='" . htmlspecialchars($perfil['perfil']) . "'"
                . " data-descripcion='" . htmlspecialchars($perfil['descripcion']) . "'"
                . " data-modulos_acceso='" . htmlspecialchars($perfil['modulos_acceso']) . "'"
                . "></div>";
        } else {
            echo "<div id='perfil_data' data-error='Perfil no encontrado'></div>";
        }
        exit; // Salir para no continuar con la ejecución de la página
    }

    if (isset($sql) && $action != 'editar') {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id_perfil);
        $stmt->execute();
        $stmt->close();
    }
}

// Procesar la creación o actualización de perfiles
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_perfil = $_POST['id_perfil'];
    $perfil = $_POST['perfil'];
    $descripcion = $_POST['descripcion'];
    $modulos_acceso = isset($_POST['modulos_acceso']) ? implode(',', $_POST['modulos_acceso']) : '';

    if ($id_perfil) {
        // Actualizar perfil
        $sql = "UPDATE spa_perfiles SET perfil=?, descripcion=?, modulos_acceso=? WHERE id_perfil=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $perfil, $descripcion, $modulos_acceso, $id_perfil);
        $stmt->execute();
        $stmt->close();
    } else {
        // Agregar nuevo perfil
        $sql = "INSERT INTO spa_perfiles (perfil, descripcion, modulos_acceso) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $perfil, $descripcion, $modulos_acceso);
        $stmt->execute();
        $stmt->close();
    }
    header('Location: perfiles.php'); // Redirigir después de guardar
    exit;
}

// Obtener todos los módulos activos
$sql_modulos = "SELECT * FROM spa_modulos WHERE estado = 'activo'";
$result_modulos = $conn->query($sql_modulos);

// Obtener todos los perfiles
$sql_perfiles = "SELECT * FROM spa_perfiles";
$result_perfiles = $conn->query($sql_perfiles);

$conn->close();
?>


    <!-- Incluir la barra de navegación -->
    <?php include 'barra_navegacion.php'; ?>

    <main>
        <!-- Botón para agregar un nuevo perfil -->
        <div class="agregar-btn">
            <a href="#" id="agregarBtn" class="btn-agregar">Agregar Perfil</a>
        </div>

        <!-- Tabla de perfiles existentes -->
        <div class="tabla">
            <h2>Perfiles Existentes</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Perfil</th>
                        <th>Descripción</th>
                        <th>Módulos de Acceso</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($perfil = $result_perfiles->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $perfil['id_perfil']; ?></td>
                            <td><?php echo $perfil['perfil']; ?></td>
                            <td><?php echo $perfil['descripcion']; ?></td>
                            <td>
                                <?php
                                $modulos_acceso = explode(',', $perfil['modulos_acceso']);
                                echo implode(', ', $modulos_acceso);
                                ?>
                            </td>
                            <td><?php echo $perfil['estado']; ?></td>
                            <td class="acciones">
                                <?php if ($perfil['estado'] == 'activo') { ?>
                                    <a href="perfiles.php?action=inactivar&id_perfil=<?php echo $perfil['id_perfil']; ?>" class="btn btn-danger">Inactivar</a>
                                <?php } else { ?>
                                    <a href="perfiles.php?action=activar&id_perfil=<?php echo $perfil['id_perfil']; ?>" class="btn btn-success">Activar</a>
                                <?php } ?>
                                <a href="#" class="btn btn-primary editarBtn" data-id="<?php echo $perfil['id_perfil']; ?>">Editar</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Modal para agregar/editar perfil -->
<div id="modal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h1>Agregar/Editar Perfil</h1>
        <form id="perfilForm" action="perfiles.php" method="post">
            <input type="hidden" name="id_perfil" id="id_perfil" value="">
            
            <label for="perfil">Perfil:</label>
            <input type="text" name="perfil" id="perfil" required><br>
            
            <label for="descripcion">Descripción:</label>
            <textarea name="descripcion" id="descripcion" rows="4" required></textarea><br>
            
            <label for="modulos_acceso">Módulos de Acceso:</label><br>
            <div class="modulos-lista">
                <?php
                $result_modulos->data_seek(0); // Resetear el puntero del resultado para reutilizar la consulta
                while ($modulo = $result_modulos->fetch_assoc()) {
                    $modulo_nombre = ucfirst($modulo['modulo']);
                    echo "<div class=\"modulo-item\"><input type=\"checkbox\" name=\"modulos_acceso[]\" value=\"$modulo_nombre\"> <label>$modulo_nombre</label></div>";
                }
                ?>
            </div><br>
            
            <input type="submit" value="Guardar Perfil">
        </form>
    </div>
</div>


<script src="../js/perfiles.js"></script>
</body>
</html>
