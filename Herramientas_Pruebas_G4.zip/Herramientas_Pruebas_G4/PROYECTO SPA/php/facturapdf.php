<?php
date_default_timezone_set('America/Guayaquil');
$username = "root";
$password = "";
$dbname = "aura spa";
$servername = "localhost";

// Conexion a la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexion fallida: " . $conn->connect_error);
}

require('../fpdf/fpdf.php'); // Incluye la biblioteca FPDF

if (isset($_GET['generate_pdf']) && isset($_GET['id_factura'])) {
    $id_factura = intval($_GET['id_factura']);
    
    // Consulta para obtener los detalles de la factura
    $query = "SELECT * FROM spa_facturas WHERE id_factura = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die('Error en la preparación de la consulta: ' . $conn->error);
    }
    $stmt->bind_param('i', $id_factura);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Verifica si la factura existe
    if ($result->num_rows === 0) {
        die('Factura no encontrada.');
    }

    // Obtiene los datos de la factura
    $factura = $result->fetch_assoc();
    
    // Crea una instancia de FPDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);
    
    // Agrega un titulo
    $pdf->Cell(0, 10, 'Factura', 0, 1, 'C');
    
    // Agrega los detalles de la factura
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, "ID Factura: {$factura['id_factura']}", 0, 1);
    $pdf->Cell(0, 10, "Cedula Cliente: {$factura['cedula_cliente']}", 0, 1);
    $pdf->Cell(0, 10, "Cedula Vendedor: {$factura['cedula_vendedor']}", 0, 1);
    $pdf->Cell(0, 10, "Fecha Emision: {$factura['fecha_emision']}", 0, 1);
    $pdf->Cell(0, 10, "Total sin IVA: {$factura['total_sin_iva']}", 0, 1);
    $pdf->Cell(0, 10, "IVA: {$factura['iva']}", 0, 1);
    $pdf->Cell(0, 10, "Valor Total: {$factura['valor_total']}", 0, 1);
    
    // Opcional: Agrega una tabla para los detalles de los productos
    $productos = json_decode($factura['productos_id_cantida'], true);
    if (!empty($productos)) {
        $pdf->Ln(10); // Salto de linea
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell(0, 10, 'Detalles de Productos', 0, 1, 'C');
        $pdf->SetFont('Arial', 'B', 12);
        
        // Tabla de productos
        $pdf->Cell(70, 10, 'Producto', 1);
        $pdf->Cell(30, 10, 'Cantidad', 1);
        $pdf->Cell(30, 10, 'Precio Unitario', 1);
        $pdf->Cell(30, 10, 'Subtotal', 1);
        $pdf->Ln();
        
        $pdf->SetFont('Arial', '', 12);
        $total_sin_iva = 0;
        foreach ($productos as $producto) {
            // Supongamos que tienes una tabla `spa_productos` con los detalles del producto
            $prod_query = "SELECT nombre_producto, precio_unitario FROM spa_productos WHERE id = ?";
            $prod_stmt = $conn->prepare($prod_query);
            if (!$prod_stmt) {
                die('Error en la preparación de la consulta de productos: ' . $conn->error);
            }
            $prod_stmt->bind_param('i', $producto['id']);
            $prod_stmt->execute();
            $prod_result = $prod_stmt->get_result();
            $prod_data = $prod_result->fetch_assoc();
            
            $nombre_producto = $prod_data['nombre_producto'];
            $precio_unitario = $prod_data['precio_unitario'];
            $cantidad = $producto['cantidad'];
            $subtotal = $precio_unitario * $cantidad;
            $total_sin_iva += $subtotal;
            
            $pdf->Cell(70, 10, $nombre_producto, 1);
            $pdf->Cell(30, 10, $cantidad, 1);
            $pdf->Cell(30, 10, number_format($precio_unitario, 2), 1);
            $pdf->Cell(30, 10, number_format($subtotal, 2), 1);
            $pdf->Ln();
        }
        
        // Agrega un resumen de total sin IVA
        $pdf->Cell(130, 10, 'Total sin IVA', 1);
        $pdf->Cell(30, 10, number_format($total_sin_iva, 2), 1);
    }

    // Cierra la conexion a la base de datos
    $stmt->close();
    $conn->close();
    
    // Envia el PDF al navegador
    $pdf->Output('I', 'factura_'.$id_factura.'.pdf');
    exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Generar PDF de Factura</title>
</head>
<body>

<h1>Generar Factura en PDF</h1>

<form action="facturapdf.php" method="get">
    <label for="id_factura">ID Factura:</label>
    <input type="number" id="id_factura" name="id_factura" required>
    <button type="submit" name="generate_pdf" value="true">Generar PDF</button>
</form>

</body>
</html>
