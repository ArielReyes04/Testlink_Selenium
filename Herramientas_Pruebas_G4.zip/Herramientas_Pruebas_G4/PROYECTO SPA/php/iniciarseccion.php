<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aura spa";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$response = array('success' => false, 'message' => '');

// Verificar si el método de solicitud es POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];

    // Preparar la consulta SQL para verificar el usuario y su estado
    $sql = "SELECT * FROM spa_usuarios WHERE user = ? AND contrasena = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        $response['message'] = "Error en la preparación de la consulta: " . $conn->error;
        echo json_encode($response);
        exit;
    }

    $stmt->bind_param("ss", $usuario, $contrasena);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $fila = $resultado->fetch_assoc();

        // Verificar el estado del usuario
        if ($fila['estado'] == 'activo') {
            $_SESSION['user'] = $fila['user'];
            $_SESSION['tipo_perfil'] = $fila['tipo_perfil'];
            $response['success'] = true;
            $response['message'] = 'success'; // Cambio de estado para éxito
        } else {
            $response['message'] = 'Tu usuario está inactivo. Contacta al administrador.';
        }
    } else {
        $response['message'] = 'Usuario o contraseña incorrectos.';
    }

    $stmt->close();
}

$conn->close();
header('Content-Type: application/json');
echo json_encode($response);
?>
