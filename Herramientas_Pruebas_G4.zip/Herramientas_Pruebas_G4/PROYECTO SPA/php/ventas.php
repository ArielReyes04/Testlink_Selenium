<?php
date_default_timezone_set('America/Guayaquil');
$username = "root";
$password = "";
$dbname = "aura spa";
$servername = "localhost";

// Conexión a la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

function registrarCambio($conn, $usuario, $tipo_cambio, $entidad, $id_entidad, $descripcion) {
    $fecha_hora = date('Y-m-d H:i:s');
    $ip_usuario = $_SERVER['REMOTE_ADDR'];
    
    $sql = "INSERT INTO spa_reportes (usuario, tipo_cambio, entidad, id_entidad, descripcion, fecha_hora, ip_usuario)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $usuario, $tipo_cambio, $entidad, $id_entidad, $descripcion, $fecha_hora, $ip_usuario);
    if (!$stmt->execute()) {
        error_log("Error al registrar cambio: " . $stmt->error); // Registrar el error en el log
    }
    $stmt->close(); // Cierra el statement después de ejecutarlo
}

$nombre_servicio = "";
$descripcion = "";
$precio = "";

// Manejo de solicitud para buscar cliente por cédula
if (isset($_GET['action']) && $_GET['action'] === 'buscar_cliente' && isset($_GET['cedula'])) {
    $cedula = $conn->real_escape_string($_GET['cedula']);
    $sql = "SELECT id_cliente, nombres, cedula, telefono, direccion, email, fnac
            FROM spa_clientes
            WHERE cedula = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $cedula);
    $stmt->execute();
    $result = $stmt->get_result();

    $cliente = $result->fetch_assoc();
    echo json_encode($cliente);
    exit;
}

// Manejo de solicitud para cargar todos los productos
if (isset($_GET['action']) && $_GET['action'] === 'load_productos') {
    $sql = "SELECT nombre_producto, codigo_producto, cantidad, precio_unitario, descripcion
            FROM spa_productos";
    $result = $conn->query($sql);

    $productos = [];
    while ($row = $result->fetch_assoc()) {
        $productos[] = $row;
    }

    echo json_encode($productos);
    exit;
}

$conn = new mysqli($servername, $username, $password, $dbname);

// Manejo de solicitud para cargar todos los servicios
if (isset($_GET['action']) && $_GET['action'] === 'load_servicios') {
    $sql = "SELECT id_servicio, nombre, descripcion, productos, precio FROM spa_servicios";
    $result = $conn->query($sql);

    $servicios = [];
    while ($row = $result->fetch_assoc()) {
        // Obtener los IDs de productos y convertirlos en un array
        $producto_ids = explode(',', $row['productos']);
$conn = new mysqli($servername, $username, $password, $dbname);

        // Preparar una consulta para obtener los productos correspondientes
        if (!empty($producto_ids)) {
            $placeholder = implode(',', array_fill(0, count($producto_ids), '?'));
            $prod_sql = "SELECT id_producto, nombre_producto FROM spa_productos WHERE id_producto IN ($placeholder)";
            $prod_stmt = $conn->prepare($prod_sql);
            if ($prod_stmt) {
                $prod_stmt->bind_param(str_repeat('i', count($producto_ids)), ...$producto_ids);
                $prod_stmt->execute();
                $prod_result = $prod_stmt->get_result();

                $productos = [];
                while ($prod_row = $prod_result->fetch_assoc()) {
                    $productos[] = $prod_row;
                }

                // Añadir productos al servicio actual
                $row['productos'] = $productos;
            } else {
                // Manejar error en la preparación de la consulta de productos
                $row['productos'] = 'Error en la consulta de productos';
            }
        } else {
            $row['productos'] = [];
        }

        $servicios[] = $row;
    }

    echo json_encode($servicios);
    exit;
}


// Manejo de solicitud para actualizar stock
if (isset($_POST['action']) && $_POST['action'] == 'actualizar_stock') {
    $codigo_producto = $_POST['codigo_producto'];
    $cantidad = $_POST['cantidad'];

    // Obtener la cantidad actual del producto
    $sql = "SELECT cantidad FROM spa_productos WHERE codigo_producto = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $codigo_producto);
    $stmt->execute();
    $result = $stmt->get_result();
    $producto = $result->fetch_assoc();

    if ($producto) {
        $cantidad_actual = $producto['cantidad'];
        $nueva_cantidad = $cantidad_actual - $cantidad;

        // Actualizar la cantidad en la base de datos
        $sql = "UPDATE spa_productos SET cantidad = ? WHERE codigo_producto = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $nueva_cantidad, $codigo_producto);
        $stmt->execute();

        echo "Stock actualizado correctamente.";
    } else {
        echo "Producto no encontrado.";
    }

    $stmt->close();
    $conn->close();
    exit;
}

// Manejo de solicitud para guardar la factura
if (isset($_POST['action']) && $_POST['action'] === 'guardar_factura') {
    $cedula_cliente = $_POST['cedula_cliente'];
    $cedula_vendedor = $_POST['cedula_vendedor'];
    $productos_id_cantidad = $_POST['productos_id_cantidad']; // JSON en formato string
    $total_sin_iva = $_POST['total_sin_iva'];
    $iva = $_POST['iva'];
    $valor_total = $_POST['valor_total'];

    // Validar que se ha ingresado un cliente y hay productos en la tabla
    if (empty($cedula_cliente) || empty($productos_id_cantidad)) {
        echo "Debe ingresar un cliente y agregar al menos un producto.";
        exit;
    }

    $sql = "INSERT INTO spa_facturas (cedula_cliente, cedula_vendedor, fecha_emision, productos_id_cantida, total_sin_iva, iva, valor_total)
            VALUES (?, ?, NOW(), ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $cedula_cliente, $cedula_vendedor, $productos_id_cantidad, $total_sin_iva, $iva, $valor_total);

    if ($stmt->execute()) {
        // Limpiar la tabla de ventas después de guardar la factura
        $sql = "DELETE FROM tabla_ventas"; // Cambia `tabla_ventas` por el nombre real de la tabla
        $conn->query($sql);
		$usuario = $_SESSION['usuario'];
        $id_entidad = $conn->insert_id;
        $tipo_cambio = "Nueva Venta";
        $descripcion_reporte = "Se agrego una venta por el valor de: '$valor_total'.";

        registrarCambio($conn, $usuario, $tipo_cambio, "Ventas", $id_entidad, $descripcion_reporte);

        echo "Factura guardada correctamente.";
    } else {
        echo "Error al guardar la factura: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
    exit;
}
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Gestión de Productos</title>
    <link href="../css/estilo_Pagina.css" rel="stylesheet" type="text/css">
    <link href="../css/estilo_Ventas.css" rel="stylesheet" type="text/css">
	    <link href="generar_factura.php" rel="stylesheet" type="text/css">

</head>

<body>
    <!-- Barra de navegación -->
    <?php include 'barra_navegacion.php'; ?>

    <main>
        <h1>VENTAS</h1>
        
        <!-- Información del Cliente -->
        <section>
            <h2>INFORMACION DEL CLIENTE</h2>
            <form id="buscarClienteForm">
                <label for="cedula">Ingresar Cédula:</label>
                <input type="text" id="cedula" name="cedula" required>
                <button type="submit">Buscar</button>
<button type="button" id="agregarClienteBtn">Agregar Cliente</button>
				<script>
document.getElementById('agregarClienteBtn').addEventListener('click', function() {
    window.location.href = 'clientes.php'; // Redirige a clientes.php
});
</script>

            </form>
            <div id="datosCliente">
                <!-- Aquí se mostrarán los datos del cliente -->
            </div>
        </section>

        <!-- Botones para añadir productos y servicios -->
        <section>
            <button id="anadirProductoBtn">Añadir Producto</button>
            <button id="anadirServicioBtn">Añadir Servicio</button>
        </section>

        <!-- Tabla para mostrar la información relevante -->
       <!-- Tabla para mostrar la información relevante -->
<section>
    <h2>Detalle de Venta</h2>
    <table id="tablaVentas">
        <thead>
            <tr>
                <th>Producto/Servicio</th>
                <th>Código</th>
                <th>Descripción</th>
                <th>Cantidad</th>
                <th>Precio Unitario</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <!-- Las filas de la tabla se llenarán dinámicamente -->
        </tbody>
        <tfoot>
            <tr>
                <td colspan="5"><strong>Total:</strong></td>
                <td id="totalVenta">0.00</td>
            </tr>
            <tr>
                <td colspan="5"><strong>IVA (15%):</strong></td>
                <td id="ivaVenta">0.00</td>
            </tr>
            <tr>
                <td colspan="5"><strong>Precio Final:</strong></td>
                <td id="precioFinal">0.00</td>
            </tr>
        </tfoot>
    </table>
</section>
   <section>
        <button id="guardarFacturaBtn">Guardar Factura</button>
        <button id="generarPdfBtn" style="display: none;">Generar PDF/XML</button>
    </section>

    <script>
    document.getElementById('guardarFacturaBtn').addEventListener('click', async function() {
        try {
            // Deshabilitar el botón mientras se procesa
            this.disabled = true;

            // Simulación de la llamada a la función guardarFactura()
            await guardarFactura(); // Reemplaza con la llamada real a tu backend

            // Mostrar el botón de generar PDF solo después de guardar la factura
            document.getElementById('generarPdfBtn').style.display = 'inline';
        } catch (error) {
            console.error('Error al guardar la factura:', error);
        } finally {
            // Volver a habilitar el botón en caso de error
            this.disabled = false;
        }
    });

    document.getElementById('generarPdfBtn').addEventListener('click', function() {
        // Crear una solicitud AJAX para generar la factura
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'generar_factura.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

        xhr.onload = function() {
            if (xhr.status >= 200 && xhr.status < 400) {
                // Mostrar la alerta si la factura fue generada exitosamente
                alert('La factura ha sido generada exitosamente.');
                // Opcional: Actualizar el contenido de la página o realizar otras acciones aquí
            } else {
                alert('Hubo un problema al generar la factura.');
            }
        };

        xhr.send();
    });

    async function guardarFactura() {
        // Simulación de la llamada a la función guardarFactura()
        // Reemplaza esta simulación con la llamada real a tu backend
        return new Promise((resolve, reject) => {
            // Aquí se realizaría la llamada real para guardar la factura
            setTimeout(() => {
                resolve();
            }, 2000); // Simular tiempo de espera
        });
    }
    </script>

    </main>
<!-- Modal para Añadir Servicio -->
<div id="modalServicio" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>

        <h2>Seleccionar Servicio</h2>
        <table id="tablaServicios">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Productos</th>
                    <th>Precio</th>
                    <th>Seleccionar</th> <!-- Nueva celda -->
                </tr>
            </thead>
            <tbody>
                <!-- Filas de servicios se llenarán dinámicamente -->
            </tbody>
        </table>
    </div>
</div>
    <!-- Modal para Añadir Producto -->
    <div id="modalProducto" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>

            <h2>Seleccionar Producto</h2>
            <table id="tablaProductos">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Código</th>
                        <th>Cantidad</th>
                        <th>Precio Unitario</th>
                        <th>Descripción</th>
                        <th>Cantidad a Añadir</th> <!-- Nueva celda -->
                    </tr>
                </thead>
                <tbody>
                    <!-- Filas de productos se llenarán dinámicamente -->
                </tbody>
            </table>
        </div>
    </div>

    <script src="../js/ventas.js"></script> <!-- Enlaza tu archivo JavaScript aquí -->

</body>
</html>
