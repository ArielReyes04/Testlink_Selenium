<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aura spa";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$message = ""; // Variable para almacenar mensajes
$message_type = ""; // Variable para almacenar el tipo de mensaje

// Obtener perfiles desde spa_perfiles
$sql_perfiles = "SELECT perfil FROM spa_perfiles WHERE estado = 'activo'";
$result_perfiles = $conn->query($sql_perfiles);

if ($conn->error) {
    die("Error al obtener perfiles: " . $conn->error);
}

// Insertar usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'insertar') {
    // Recoger datos del formulario
    $nombre_usuario = $_POST['nombre_usuario'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];
    $tipo_perfil = $_POST['tipo_perfil'];
    $cedula = $_POST['cedula'];
    $user = $_POST['user'];
    $password = $_POST['password'];
    $fecha_registro = $_POST['fecha_registro'];

    // Preparar y ejecutar la consulta SQL
    $stmt = $conn->prepare("INSERT INTO spa_usuarios (nombre_usuario, correo, telefono, tipo_perfil, cedula, user, contrasena, fecha_registro) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $nombre_usuario, $correo, $telefono, $tipo_perfil, $cedula, $user, $password, $fecha_registro);

    if ($stmt->execute()) {
        $message = "Nuevo usuario creado exitosamente";
		  $message_type = "Mensaje";

    } else {
        $message = "Error al crear usuario: " . $stmt->error;
        $message_type = "error";
    }

    $stmt->close();
}

// Editar usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'editar') {
    // Recoger datos del formulario
    $id_usuario = $_POST['id_usuario'];
    $nombre_usuario = $_POST['nombre_usuario'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];
    $tipo_perfil = $_POST['tipo_perfil'];
    $cedula = $_POST['cedula'];
    $user = $_POST['user'];
    $password = $_POST['password'];
    $fecha_registro = $_POST['fecha_registro'];

    // Preparar y ejecutar la consulta SQL
    $stmt = $conn->prepare("UPDATE spa_usuarios SET nombre_usuario=?, correo=?, telefono=?, tipo_perfil=?, cedula=?, user=?, contrasena=?, fecha_registro=? WHERE id_usuario=?");
    $stmt->bind_param("ssssssssi", $nombre_usuario, $correo, $telefono, $tipo_perfil, $cedula, $user, $password, $fecha_registro, $id_usuario);

    if ($stmt->execute()) {
        $message = "Usuario editado exitosamente";
        $message_type = "Mensaje";
    } else {
        $message = "Error al editar usuario: " . $stmt->error;
        $message_type = "error";
    }

    $stmt->close();
}

// Activar/Inactivar usuario
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id_usuario = $_GET['id'];
    $action = $_GET['action'];
    $nuevo_estado = ($action == 'activar') ? 'activo' : 'inactivo';

    $sql = "UPDATE spa_usuarios SET estado='$nuevo_estado' WHERE id_usuario='$id_usuario'";
    if ($conn->query($sql) === TRUE) {
        $message = "Usuario $nuevo_estado exitosamente";
        $message_type = "Mensaje";
    } else {
        $message = "Error al $action usuario: " . $conn->error;
        $message_type = "error";
    }
}

// Obtener todos los usuarios
$sql_usuarios = "SELECT * FROM spa_usuarios";
$result_usuarios = $conn->query($sql_usuarios);

if ($conn->error) {
    die("Error al obtener usuarios: " . $conn->error);
}

// Prellenar el formulario con los datos del usuario a editar
$usuario_a_editar = null;
if (isset($_GET['edit_id'])) {
    $id_usuario = $_GET['edit_id'];
    $sql_usuario = "SELECT * FROM spa_usuarios WHERE id_usuario='$id_usuario'";
    $result_usuario = $conn->query($sql_usuario);
    $usuario_a_editar = $result_usuario->fetch_assoc();
    echo "<script>window.onload = function() { abrirModal(); };</script>";
}
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Panel de Administrador - Usuarios</title>
    <link href="../css/estilo_Usuarios.css" rel="stylesheet" type="text/css">
    <link href="../css/estilo_Pagina.css" rel="stylesheet" type="text/css">
</head>

<body>
    <!-- Incluir barra de navegación -->
    <?php include 'barra_navegacion.php'; ?>

    <!-- Contenedor principal -->
    <div class="container">
       <h1>Gestion de Usuarios</h1>
        <div class="boton-agregar">
            <button onclick="abrirModal()">Agregar Usuario</button>
        </div>

        <!-- Tabla de usuarios -->
        <div class="tabla-usuarios">
            <h2>Lista de Usuarios</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID Usuario</th>
                        <th>Nombre Usuario</th>
                        <th>Correo</th>
                        <th>Teléfono</th>
                        <th>Tipo Perfil</th>
                        <th>Cédula</th>
                        <th>Usuario</th>
                        <th>Contraseña</th>
                        <th>Fecha Registro</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result_usuarios->num_rows > 0) {
                        while ($usuario = $result_usuarios->fetch_assoc()) {
                            $estado_accion = $usuario['estado'] == 'activo' ? 'inactivar' : 'activar';
                            $estado_texto = $usuario['estado'] == 'activo' ? 'Inactivar' : 'Activar';
                            echo "<tr>
                                <td>{$usuario['id_usuario']}</td>
                                <td>{$usuario['nombre_usuario']}</td>
                                <td>{$usuario['correo']}</td>
                                <td>{$usuario['telefono']}</td>
                                <td>{$usuario['tipo_perfil']}</td>
                                <td>{$usuario['cedula']}</td>
                                <td>{$usuario['user']}</td>
                                <td>{$usuario['contrasena']}</td>
                                <td>{$usuario['fecha_registro']}</td>
                                <td>{$usuario['estado']}</td>
                               <td class='acciones'>
                                    <button class='btn-editar' onclick=\"editarUsuario({$usuario['id_usuario']})\">Editar</button>
                                    <button class='btn-activar-inactivar " . ($usuario['estado'] == 'activo' ? 'btn-inactivar' : 'btn-activar') . "' onclick=\"window.location.href='usuarios.php?action={$estado_accion}&id={$usuario['id_usuario']}'\">{$estado_texto}</button>
                                </td>

                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='11'>No hay usuarios disponibles</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal para el formulario -->
    <div id="modalFormulario" class="modal">
        <div class="modal-contenido">
            <span class="cerrar" onclick="cerrarModal()">&times;</span>
            <h1>Gestión de Usuarios</h1>

            <form id="formularioUsuario" action="usuarios.php" method="post">
                <input type="hidden" id="id_usuario" name="id_usuario" value="<?php echo $usuario_a_editar['id_usuario'] ?? ''; ?>">
                <input type="hidden" name="accion" value="<?php echo isset($usuario_a_editar) ? 'editar' : 'insertar'; ?>">

                <label for="nombre_usuario">Nombre Usuario:</label>
    <input type="text" id="nombre_usuario" name="nombre_usuario" value="<?php echo $usuario_a_editar['nombre_usuario'] ?? ''; ?>" <?php echo isset($usuario_a_editar) ? 'readonly' : ''; ?> required>
<div id="nombre_usuario-error" class="error"></div>

                <label for="correo">Correo:</label>
                <input type="email" id="correo" name="correo" value="<?php echo $usuario_a_editar['correo'] ?? ''; ?>" required>
<div id="correo-error" class="error"></div>

                <label for="telefono">Teléfono:</label>
                <input type="text" id="telefono" name="telefono" value="<?php echo $usuario_a_editar['telefono'] ?? ''; ?>" required>
<div id="telefono-error" class="error"></div>

                <label for="tipo_perfil">Tipo Perfil:</label>
                <select id="tipo_perfil" name="tipo_perfil" required>
                    <?php while ($perfil = $result_perfiles->fetch_assoc()): ?>
                        <option value="<?php echo $perfil['perfil']; ?>" <?php echo isset($usuario_a_editar) && $usuario_a_editar['tipo_perfil'] == $perfil['perfil'] ? 'selected' : ''; ?>>
                            <?php echo $perfil['perfil']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>

                <label for="cedula">Cédula:</label>
    <input type="text" id="cedula" name="cedula" value="<?php echo $usuario_a_editar['cedula'] ?? ''; ?>" <?php echo isset($usuario_a_editar) ? 'readonly' : ''; ?> required>
<div id="cedula-error" class="error"></div>

				<label for="user">Usuario:</label>
    <input type="text" id="user" name="user" value="<?php echo $usuario_a_editar['user'] ?? ''; ?>" <?php echo isset($usuario_a_editar) ? 'readonly' : ''; ?> required>

                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" value="<?php echo $usuario_a_editar['contrasena'] ?? ''; ?>" required>
							<div id="password-error" class="error"></div>

<?php
date_default_timezone_set('America/Guayaquil');

?>
                <label for="fecha_registro">Fecha Registro:</label>
                <input type="text" id="fecha_registro" name="fecha_registro" value="<?php echo isset($usuario_a_editar) ? $usuario_a_editar['fecha_registro'] : date('Y-m-d H:i:s'); ?>" readonly>
				

                <button type="submit" class="<?php echo isset($usuario_a_editar) ? 'actualizar' : ''; ?>">
        <?php echo isset($usuario_a_editar) ? 'Actualizar' : 'Agregar'; ?>
    </button>
            </form>
        </div>
    </div>

    <!-- Modal para mensajes -->
    <?php if (isset($message) && !empty($message)): ?>
    <div id="modalMensaje" class="modal">
        <div class="modal-contenido">
            <span class="cerrar" onclick="cerrarMensaje()">&times;</span>
            <h2><?php echo ucfirst($message_type); ?>!</h2>
            <p><?php echo $message; ?></p>
        </div>
    </div>
    <script>
        function cerrarMensaje() {
            document.getElementById('modalMensaje').style.display = 'none';
        }

        function mostrarMensaje() {
            document.getElementById('modalMensaje').style.display = 'block';
        }

        window.onload = function() {
            if (<?php echo json_encode(isset($message) && !empty($message)); ?>) {
                mostrarMensaje();
            }
        }
    </script>
    <?php endif; ?>

    <script>
        function abrirModal() {
            document.getElementById('modalFormulario').style.display = 'block';
        }

        function cerrarModal() {
            document.getElementById('modalFormulario').style.display = 'none';
        }

        function editarUsuario(id) {
            window.location.href = 'usuarios.php?edit_id=' + id;
        }
    </script>
		<script src="../js/usuarios.js"></script>

</body>
</html>

<?php
$conn->close();
?>
