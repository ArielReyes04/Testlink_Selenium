<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user'])) {
    header("Location: iniciarseccion.php");
    exit();
}

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aura spa";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el tipo de perfil del usuario desde la sesión
$tipo_perfil = $_SESSION['tipo_perfil'];
$user = $_SESSION['user']; // Nombre de usuario para la sesión

// Obtener el nombre completo del usuario
$sql = "SELECT nombre_usuario FROM spa_usuarios WHERE correo = '$user'";
$result = $conn->query($sql);

$nombre_usuario = $user; // Valor por defecto

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $nombre_usuario = $row['nombre_usuario'];
}

// Obtener los módulos a los que el perfil tiene acceso
$sql = "SELECT modulos_acceso FROM spa_perfiles WHERE perfil = '$tipo_perfil' AND estado = 'activo'";
$result = $conn->query($sql);

$modulos = [];

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $modulos = explode(',', $row['modulos_acceso']);
}

// Consultar la dirección PHP de cada módulo activo
$enlaces = [];
if (!empty($modulos)) {
    $modulos_lista = "'" . implode("','", $modulos) . "'";
    $sql_modulos = "SELECT modulo, direccion_php FROM spa_modulos WHERE modulo IN ($modulos_lista) AND estado = 'activo'";
    $result_modulos = $conn->query($sql_modulos);

    if ($result_modulos && $result_modulos->num_rows > 0) {
        while ($row_modulo = $result_modulos->fetch_assoc()) {
            $enlaces[$row_modulo['modulo']] = $row_modulo['direccion_php'];
        }
    }
}

$conn->close();
?>

<nav class="navbar">
    <ul>
        <li><a href="principal.php" class="home-icon"><img src="../img/sss.png" alt="Inicio" width="84" height="88"></a></li>
        
        <?php foreach ($enlaces as $modulo => $direccion): ?>
            <li><a href="<?php echo $direccion; ?>"><?php echo $modulo; ?></a></li>
        <?php endforeach; ?>
    </ul>          
    <a href="../index.html" class="logout">Cerrar sesión</a>
</nav>
