<?php
session_start();
date_default_timezone_set('America/Guayaquil');
$username = "root";
$password = "";
$dbname = "aura spa";
$servername = "localhost"; // Asegúrate de definir el servidor de la base de datos

// Conexión a la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

function registrarCambio($conn, $usuario, $tipo_cambio, $entidad, $id_entidad, $descripcion) {
    $fecha_hora = date('Y-m-d H:i:s');
    $ip_usuario = $_SERVER['REMOTE_ADDR'];
    
    $sql = "INSERT INTO spa_reportes (usuario, tipo_cambio, entidad, id_entidad, descripcion, fecha_hora, ip_usuario)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $usuario, $tipo_cambio, $entidad, $id_entidad, $descripcion, $fecha_hora, $ip_usuario);
    if (!$stmt->execute()) {
        error_log("Error al registrar cambio: " . $stmt->error); // Registrar el error en el log
    }
    $stmt->close(); // Cierra el statement después de ejecutarlo
}

$message = ""; // Variable para almacenar mensajes

// Insertar nuevo producto
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['guardar'])) {
        $nombre_producto = $_POST['nombre_producto'];
        $codigo_producto = $_POST['codigo_producto'];
        $cantidad = $_POST['cantidad'];
        $precio_unitario = $_POST['precio_unitario'];
        $descripcion = $_POST['descripcion'];
        $categoria_nombre = $_POST['categoria']; // Obtener el nombre de la categoría

        // Obtener el ID de la categoría basado en el nombre
        $cat_sql = "SELECT id_categoria FROM spa_categorias WHERE categoria = '$categoria_nombre'";
        $cat_result = $conn->query($cat_sql);

        if ($cat_result && $cat_result->num_rows > 0) {
            $categoria_id = $cat_result->fetch_assoc()['id_categoria'];
        } else {
            $message = "Categoría no encontrada.";
            // Manejar el error adecuadamente, por ejemplo, redirigir o mostrar un mensaje
        }

        $fechaIngreso = date('Y-m-d H:i:s'); // Fecha y hora actual

        // Insertar el producto con el ID de categoría
		$sql = "INSERT INTO spa_productos (nombre_producto, codigo_producto, cantidad, precio_unitario, descripcion, fechaIngreso, categoria)
       			 VALUES ('$nombre_producto', '$codigo_producto', $cantidad, $precio_unitario, '$descripcion', '$fechaIngreso', '$categoria_nombre')";

        if ($conn->query($sql) === TRUE) {
			$usuario = $_SESSION['usuario'];
            $id_entidad = $conn->insert_id;
            $tipo_cambio = "Nuevo Producto";
            $descripcion_reporte = "Se creó el producto '$nombre_producto' con código '$codigo_producto'.";

            registrarCambio($conn, $usuario, $tipo_cambio, "Producto", $id_entidad, $descripcion_reporte);

            $message = "Producto guardado exitosamente";
        } else {
            $message = "Error al guardar producto: " . $conn->error;
        }
    }

    // Actualizar producto existente
 // Actualizar producto existente
		if (isset($_POST['editar'])) {
			$id = intval($_POST['id']);
			$nombre_producto = $_POST['nombre_producto'];
			$codigo_producto = $_POST['codigo_producto'];
			$cantidad = $_POST['cantidad'];
			$precio_unitario = $_POST['precio_unitario'];
			$descripcion = $_POST['descripcion'];
			$categoria_nombre = $_POST['categoria']; // Obtener el nombre de la categoría

			// Obtener el ID de la categoría basado en el nombre
			$cat_sql = "SELECT id_categoria FROM spa_categorias WHERE categoria = '$categoria_nombre'";
			$cat_result = $conn->query($cat_sql);

			if ($cat_result && $cat_result->num_rows > 0) {
				$categoria_id = $cat_result->fetch_assoc()['id_categoria'];
			} else {
				$message = "Categoría no encontrada.";
				// Manejar el error adecuadamente
				exit; // Salir si la categoría no se encuentra
			}

    // Actualizar el producto con el nuevo ID de categoría
    $sql = "UPDATE spa_productos SET nombre_producto='$nombre_producto', codigo_producto='$codigo_producto', cantidad=$cantidad, 
            precio_unitario=$precio_unitario, descripcion='$descripcion', categoria='$categoria_nombre' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
		$usuario = $_SESSION['usuario'];
            $tipo_cambio = "Actualización Producto";
            $descripcion_reporte = "Se actualizó el producto '$nombre_producto' con código '$codigo_producto'.";

            registrarCambio($conn, $usuario, $tipo_cambio, "Producto", $id, $descripcion_reporte);

        $message = "Producto actualizado exitosamente";
    } else {
        $message = "Error al actualizar producto: " . $conn->error;
    }
}


    // Actualizar cantidad del producto
    if (isset($_POST['aumentar_cantidad'])) {
        $id = intval($_POST['id']);
        $cantidad_aumentar = intval($_POST['cantidad_aumentar']);

        if ($cantidad_aumentar > 0) {
            $sql = "UPDATE spa_productos SET cantidad = cantidad + $cantidad_aumentar WHERE id = $id";

            if ($conn->query($sql) === TRUE) {
				$usuario = $_SESSION['usuario'];
                $tipo_cambio = "Aumento de Cantidad";
                $descripcion_reporte = "Se aumentó la cantidad del producto con ID $id en $cantidad_aumentar unidades.";

                registrarCambio($conn, $usuario, $tipo_cambio, "Producto", $id, $descripcion_reporte);

                $message = "Cantidad aumentada exitosamente";
            } else {
                $message = "Error al aumentar cantidad: " . $conn->error;
            }
        } else {
            $message = "Por favor, ingrese una cantidad válida.";
        }
    }

    // Cambiar estado del producto
    if (isset($_POST['cambiar_estado'])) {
        $id = intval($_POST['id']);
        $nuevo_estado = $_POST['cambiar_estado']; // 'activo' o 'inactivo'

        $sql = "UPDATE spa_productos SET estado = '$nuevo_estado' WHERE id = $id";

        if ($conn->query($sql) === TRUE) {
			$usuario = $_SESSION['usuario'];
            $tipo_cambio = $nuevo_estado == 'activo' ? "Activación de Producto" : "Desactivación de Producto";
            $descripcion_reporte = "El estado del producto con ID $id fue cambiado a '$nuevo_estado'.";

            registrarCambio($conn, $usuario, $tipo_cambio, "Producto", $id, $descripcion_reporte);

            $message = $nuevo_estado == 'activo' ? "Producto activado exitosamente" : "Producto desactivado exitosamente";
        } else {
            $message = "Error al actualizar estado: " . $conn->error;
        }
    }

    // Eliminar producto
    if (isset($_POST['eliminar'])) {
        $id = intval($_POST['id']);

        $sql = "UPDATE spa_productos SET estado = 'inactivo' WHERE id = $id";

        if ($conn->query($sql) === TRUE) {
			$usuario = $_SESSION['usuario'];
            $tipo_cambio = "Eliminación de Producto";
            $descripcion_reporte = "El producto con ID $id fue desactivado.";

            registrarCambio($conn, $usuario, $tipo_cambio, "Producto", $id, $descripcion_reporte);

            $message = "Producto desactivado exitosamente";
        } else {
            $message = "Error al desactivar producto: " . $conn->error;
        }
    }
}

// Obtener productos
$sql = "SELECT * FROM spa_productos";
$resultado = $conn->query($sql);

// Verificar si la consulta SELECT tiene errores
if (!$resultado) {
    die("Error en la consulta SELECT: " . $conn->error);
}

// Obtener datos del producto a editar si se ha enviado el ID
$edit_product = null;
if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $edit_sql = "SELECT * FROM spa_productos WHERE id = $edit_id";
    $edit_result = $conn->query($edit_sql);
    
    // Verificar si la consulta SELECT tiene errores
    if (!$edit_result) {
        die("Error en la consulta SELECT para editar: " . $conn->error);
    }

    if ($edit_result->num_rows > 0) {
        $edit_product = $edit_result->fetch_assoc();
    } else {
        $message = "Producto no encontrado.";
    }
}

// Insertar nueva categoría
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['guardar_categoria'])) {
        $nombre_categoria = $_POST['nombre_categoria'];
        $descripcion_categoria = $_POST['descripcion_categoria'];

        // Verificar si se está actualizando una categoría existente
        if (isset($_POST['category_id']) && !empty($_POST['category_id'])) {
            $category_id = intval($_POST['category_id']);
            $sql = "UPDATE spa_categorias SET nombre_categoria='$nombre_categoria', descripcion='$descripcion_categoria' WHERE id=$category_id";
        } else {
            // Insertar nueva categoría
            $sql = "INSERT INTO spa_categorias (categoria, descripcion) VALUES ('$nombre_categoria', '$descripcion_categoria')";
        }

        if ($conn->query($sql) === TRUE) {
            $message = "Categoría guardada exitosamente";
        } else {
            $message = "Error al guardar categoría: " . $conn->error;
        }
    }

}

// Obtener categorías para desplegar en el modal
$categories_sql = "SELECT * FROM spa_categorias";
$categories_result = $conn->query($categories_sql);

// Verificar si la consulta SELECT tiene errores
if (!$categories_result) {
    die("Error en la consulta SELECT de categorías: " . $conn->error);
}
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Gestión de Productos</title>
    <link href="../css/estilo_Pagina.css" rel="stylesheet" type="text/css">
    <link href="../css/estilo_Bodega.css" rel="stylesheet" type="text/css">
    <script src="../js/bodega.js" defer></script>
</head>

<body>
    <!-- Barra de navegación -->
    <?php include 'barra_navegacion.php'; ?>

            <h1>Gestion de Bodega</h1>
    <div class="content">
        <h1>Gestión de Productos</h1>

        <!-- Botón para abrir el modal de agregar producto -->
        <button id="openModal" class="btn btn-primary">Agregar Producto</button>
		
		<!-- Botón de Categoría en la esquina superior derecha -->
    <button id="categoryButton" class="btn btn-secondary">Categoría</button>

            <h2>Lista de Bodega</h2>

<!-- Modal para agregar/editar productos -->
<div id="productModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2 id="modalTitle">Agregar Producto</h2>
        <form action="bodega.php" method="post" id="productForm">
            <input type="hidden" name="id" id="id" value="">
            
            <label for="nombre_producto">Nombre Producto:</label>
            <input type="text" id="nombre_producto" name="nombre_producto" value=""><br>
            <div id="nombre_producto-error" class="error"></div>
			
            <label for="codigo_producto">Código Producto:</label>
            <input type="text" id="codigo_producto" name="codigo_producto" value=""><br>
			<div id="codigo_producto-error" class="error"></div>
            
            <label for="cantidad">Cantidad:</label>
            <input type="number" id="cantidad" name="cantidad" value=""><br>
			<div id="cantidad-error" class="error"></div>
            
            <label for="precio_unitario">Precio Unitario:</label>
            <input type="text" id="precio_unitario" name="precio_unitario" value=""><br>
			<div id="precio_unitario-error" class="error"></div>
            
            <label for="descripcion">Descripción:</label>
            <input type="text" id="descripcion" name="descripcion" value=""><br>
            
            <label for="fechaIngreso">Fecha de Ingreso:</label>
            <input type="text" id="fechaIngreso" name="fechaIngreso" value="<?php echo date('Y-m-d H:i:s'); ?>" readonly><br>
            
            <!-- Selección de categoría -->
			<label for="categoria">Categoría:</label>
			<select id="categoria" name="categoria">
				<?php while ($cat = $categories_result->fetch_assoc()): ?>
					<option value="<?php echo htmlspecialchars($cat['categoria']); ?>">
						<?php echo htmlspecialchars($cat['categoria']); ?>
					</option>
				<?php endwhile; ?>
			</select><br>
            <button type="submit" name="guardar" id="formSubmitButton" class="btn btn-primary">Guardar</button>
        </form>
    </div>
</div>

		
        <!-- Modal para agregar/editar categorías -->
        <div id="categoryModal" class="modal">
            <div class="modal-content">
                <span class="close-category">&times;</span>
                <h2 id="categoryModalTitle">Agregar Categoría</h2>
                <form action="bodega.php" method="post" id="categoryForm">
                    <input type="hidden" name="category_id" id="category_id" value="">
                    
                    <label for="nombre_categoria">Nombre Categoría:</label>
                    <input type="text" id="nombre_categoria" name="nombre_categoria" value=""><br>
                    
                    <label for="descripcion_categoria">Descripción:</label>
                    <input type="text" id="descripcion_categoria" name="descripcion_categoria" value=""><br>
                    
                    <button type="submit" name="guardar_categoria" id="categorySubmitButton" class="btn btn-primary">Guardar Categoría</button>
                </form>
            </div>
        </div>

        <!-- Mensajes de éxito o error -->
        <?php if (!empty($message)) { ?>
            <div class="message"><?php echo $message; ?></div>
        <?php } ?>

        <!-- Tabla de productos -->
        <div class="tabla">
            <table border="1">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre Producto</th>
                        <th>Código Producto</th>
                        <th>Cantidad</th>
                        <th>Precio Unitario</th>
                        <th>Descripción</th>
                        <th>Fecha de Ingreso</th>
						 <th>Categoría</th> <!-- Nueva columna -->
						
                        <th>Estado</th>

                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $resultado->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['id']); ?></td>
                            <td><?php echo htmlspecialchars($row['nombre_producto']); ?></td>
                            <td><?php echo htmlspecialchars($row['codigo_producto']); ?></td>
                            <td><?php echo htmlspecialchars($row['cantidad']); ?></td>
                            <td><?php echo htmlspecialchars($row['precio_unitario']); ?></td>
                            <td><?php echo htmlspecialchars($row['descripcion']); ?></td>
                            <td><?php echo htmlspecialchars($row['fechaIngreso']); ?></td>
							<td><?php echo htmlspecialchars($row['categoria']); ?></td>



                            <td><?php echo htmlspecialchars($row['estado']); ?></td>
                            <td>
                                <button type="button" class="btn btn-edit" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($row)); ?>)">Editar</button>
                                <form action="bodega.php" method="post" style="display:inline;">
                                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
                                    <input type="number" name="cantidad_aumentar" min="1" placeholder="Cantidad">
                                    <button type="submit" name="aumentar_cantidad" class="btn btn-primary">Aumentar Cantidad</button>
                                </form>
                                <form action="bodega.php" method="post" style="display:inline;">
                                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
                                    <?php if ($row['estado'] == 'activo'): ?>
                                        <button type="submit" name="cambiar_estado" value="inactivo" class="btn btn-danger">Desactivar</button>
                                    <?php else: ?>
                                        <button type="submit" name="cambiar_estado" value="activo" class="btn btn-success">Activar</button>
                                    <?php endif; ?>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>