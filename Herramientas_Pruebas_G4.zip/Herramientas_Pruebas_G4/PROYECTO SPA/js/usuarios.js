document.addEventListener("DOMContentLoaded", function() {
    const formulario = document.getElementById("formularioUsuario");
    const nombreUsuario = document.getElementById("nombre_usuario");
    const correo = document.getElementById("correo");
    const telefono = document.getElementById("telefono");
    const cedula = document.getElementById("cedula");
    const password = document.getElementById("password");

    // Función para validar el nombre de usuario
    function validarNombreUsuario() {
        const errorDiv = document.getElementById("nombre_usuario-error");
        const nombrePattern = /^[A-Za-z\s]+$/;
        if (!nombrePattern.test(nombreUsuario.value)) {
            errorDiv.textContent = "El nombre de usuario solo debe contener letras.";
            return false;
        } else {
            errorDiv.textContent = "";
            return true;
        }
    }

    // Función para validar el correo
    function validarCorreo() {
        const errorDiv = document.getElementById("correo-error");
        const emailPattern = /^[^\s@]+@(gmail\.com|hotmail\.com)$/;
        if (!emailPattern.test(correo.value)) {
            errorDiv.textContent = "El correo debe terminar en @gmail.com o @hotmail.com.";
            return false;
        } else {
            errorDiv.textContent = "";
            return true;
        }
    }

    // Función para validar el teléfono
    function validarTelefono() {
        const errorDiv = document.getElementById("telefono-error");
        const phonePattern = /^\d{10}$/;
        if (!phonePattern.test(telefono.value)) {
            errorDiv.textContent = "El teléfono debe tener 10 dígitos numéricos.";
            return false;
        } else {
            errorDiv.textContent = "";
            return true;
        }
    }

    // Función para validar la cédula
    function validarCedula() {
        const errorDiv = document.getElementById("cedula-error");
        const cedulaPattern = /^\d{10}$/;
        if (!cedulaPattern.test(cedula.value)) {
            errorDiv.textContent = "La cédula debe tener 10 dígitos numéricos.";
            return false;
        } else {
            errorDiv.textContent = "";
            return true;
        }
    }

    // Función para validar la contraseña
    function validarPassword() {
        const errorDiv = document.getElementById("password-error");
        const passwordPattern = /^(?=.*[A-Z])(?=.*\d)[A-Za-z\d]{6,}$/;
        if (!passwordPattern.test(password.value)) {
            errorDiv.textContent = "La contraseña debe tener al menos 6 caracteres, una mayúscula y un número.";
            return false;
        } else {
            errorDiv.textContent = "";
            return true;
        }
    }

    // Función para validar el formulario completo
    function validarFormulario() {
        let esValido = true;
        if (!validarNombreUsuario()) esValido = false;
        if (!validarCorreo()) esValido = false;
        if (!validarTelefono()) esValido = false;
        if (!validarCedula()) esValido = false;
        if (!validarPassword()) esValido = false;
        return esValido;
    }

    // Validación en el envío del formulario
    formulario.addEventListener("submit", function(event) {
        if (!validarFormulario()) {
            event.preventDefault(); // Evita el envío del formulario si no es válido
        }
    });

    // Validar en tiempo real al cambiar los campos
    nombreUsuario.addEventListener("input", validarNombreUsuario);
    correo.addEventListener("input", validarCorreo);
    telefono.addEventListener("input", validarTelefono);
    cedula.addEventListener("input", validarCedula);
    password.addEventListener("input", validarPassword);
});
