document.addEventListener('DOMContentLoaded', function() {
    var modal = document.getElementById("clientModal");
    var btn = document.getElementById("openModal");
    var span = document.getElementsByClassName("close")[0];
    var form = document.getElementById("clientForm");
    var modalTitle = document.getElementById("modalTitle");
    var formSubmitButton = document.getElementById("formSubmitButton");

    // Abrir modal al hacer clic en el botón "Agregar Cliente"
    btn.onclick = function() {
        modalTitle.textContent = "Agregar Cliente";
        form.reset();
        modal.style.display = "block";
    }

    // Cerrar modal al hacer clic en la "X"
    span.onclick = function() {
        modal.style.display = "none";
    }

    // Cerrar modal al hacer clic fuera del contenido del modal
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Función para abrir el modal en modo edición
    window.openEditModal = function(clientData) {
        modalTitle.textContent = "Editar Cliente";
        document.getElementById("id_cliente").value = clientData.id_cliente;
        document.getElementById("nombres").value = clientData.nombres;
        document.getElementById("cedula").value = clientData.cedula;
        document.getElementById("telefono").value = clientData.telefono;
        document.getElementById("direccion").value = clientData.direccion;
        document.getElementById("email").value = clientData.email;
        document.getElementById("fnac").value = clientData.fnac;
        modal.style.display = "block";
    }
});