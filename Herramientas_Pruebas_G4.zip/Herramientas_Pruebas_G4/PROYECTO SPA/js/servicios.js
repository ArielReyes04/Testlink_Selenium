document.addEventListener("DOMContentLoaded", function() {
    // Cargar datos del localStorage al abrir la página
    cargarDatosDelFormulario();

    // Cargar productos si hay una categoría seleccionada
    const categoriaSelect = document.getElementById('categoria');
    if (categoriaSelect.value) {
        cargarProductosAJAX(categoriaSelect.value);
    }
});

function mostrarModal() {
    document.getElementById('modal').style.display = 'block';
}

function cerrarModal() {
    document.getElementById('modal').style.display = 'none';
    document.getElementById('formulario').reset();
    document.getElementById('lista_productos').innerHTML = '';
}

function cargarProductosAJAX(categoria) {
    fetch(`servicios.php?action=cargar_productos&categoria=${categoria}`)
        .then(response => response.json())
        .then(data => {
            const productosSelect = document.getElementById('productos');
            productosSelect.innerHTML = ""; // Limpiar las opciones
            if (data.error) {
                alert("Error al cargar productos: " + data.error);
            } else {
                data.forEach(producto => {
                    const option = document.createElement('option');
                    option.value = producto.id;
                    option.text = producto.nombre_producto;
                    productosSelect.appendChild(option);
                });
            }
        })
        .catch(error => console.error('Error:', error));
}

function agregarProducto() {
    const productosSelect = document.getElementById('productos');
    const listaProductos = document.getElementById('lista_productos');

    Array.from(productosSelect.selectedOptions).forEach(option => {
        const li = document.createElement('li');
        li.textContent = option.text;
        li.dataset.id = option.value; // Almacenar el ID del producto en data-id
        li.innerHTML += ' <button type="button" onclick="quitarProducto(this)">Quitar</button>';
        listaProductos.appendChild(li);
    });

    actualizarProductosHidden();
}

function quitarProducto(button) {
    button.parentElement.remove();
    actualizarProductosHidden();
}

function actualizarProductosHidden() {
    const listaProductos = document.getElementById('lista_productos');
    const productosHidden = document.getElementById('productos_hidden');

    const ids = Array.from(listaProductos.children).map(li => li.dataset.id);
    productosHidden.value = ids.join(','); // Guardar los IDs como una cadena separada por comas
}

function guardarDatosAntesDeEnviar() {
    // Guardar datos del formulario en localStorage
    localStorage.setItem('nombre_servicio', document.getElementById('nombre_servicio').value);
    localStorage.setItem('descripcion', document.getElementById('descripcion').value);
    localStorage.setItem('precio', document.getElementById('precio').value);

    // Guardar productos agregados en localStorage
    const productos = Array.from(document.getElementById('lista_productos').children).map(li => ({
        id: li.dataset.id,
        nombre: li.textContent
    }));
    localStorage.setItem('productos_agregados', JSON.stringify(productos));

    // Actualizar el campo hidden con los IDs de productos antes de enviar
    actualizarProductosHidden();
}

function cargarDatosDelFormulario() {
    // Cargar datos del formulario desde localStorage
    if (localStorage.getItem('nombre_servicio')) {
        document.getElementById('nombre_servicio').value = localStorage.getItem('nombre_servicio');
    }
    if (localStorage.getItem('descripcion')) {
        document.getElementById('descripcion').value = localStorage.getItem('descripcion');
    }
    if (localStorage.getItem('precio')) {
        document.getElementById('precio').value = localStorage.getItem('precio');
    }

    // Cargar productos agregados desde localStorage
    if (localStorage.getItem('productos_agregados')) {
        const productos = JSON.parse(localStorage.getItem('productos_agregados'));
        const listaProductos = document.getElementById('lista_productos');
        listaProductos.innerHTML = ""; // Limpiar la lista actual
        productos.forEach(producto => {
            const li = document.createElement('li');
            li.textContent = producto.nombre;
            li.dataset.id = producto.id; // Almacenar el ID del producto en data-id
            li.innerHTML += ' <button type="button" onclick="quitarProducto(this)">Quitar</button>';
            listaProductos.appendChild(li);
        });
    }
}


function editarServicio(id_servicio) {
    fetch(`servicios.php?action=obtener_servicio&id_servicio=${id_servicio}`)
        .then(response => response.json())
        .then(servicio => {
            if (servicio.error) {
                alert("Error al obtener datos del servicio: " + servicio.error);
            } else {
                // Mostrar modal y cargar datos del servicio en el formulario
                mostrarModal();
                document.getElementById('id_servicio_hidden').value = servicio.id_servicio;
                document.getElementById('nombre_servicio').value = servicio.nombre;
                document.getElementById('descripcion').value = servicio.descripcion;
                document.getElementById('precio').value = servicio.precio;

                // Limpiar lista de productos y añadir los productos del servicio
                const listaProductos = document.getElementById('lista_productos');
                listaProductos.innerHTML = "";
                for (const [id_producto, nombre_producto] of Object.entries(servicio.productos_nombres)) {
                    const li = document.createElement('li');
                    li.textContent = nombre_producto; // Muestra el nombre del producto
                    li.dataset.id = id_producto; // Almacenar el ID del producto en data-id
                    li.innerHTML += ' <button type="button" onclick="quitarProducto(this)">Quitar</button>';
                    listaProductos.appendChild(li);
                }
            }
        })
        .catch(error => console.error('Error:', error));
}


function cambiarEstado(id_servicio, estado_actual) {
    const nuevo_estado = (estado_actual === 'activo') ? 'inactivo' : 'activo';

    fetch('servicios.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=cambiar_estado&id_servicio=${id_servicio}&nuevo_estado=${nuevo_estado}`
    })
    .then(response => response.text())
    .then(data => {
        if (data.includes('exitosamente')) {
            location.reload(); // Recargar la página para reflejar el cambio de estado
        } else {
            console.error("Error al cambiar el estado:", data);
        }
    })
    .catch(error => console.error('Error:', error));
}


document.addEventListener("DOMContentLoaded", function() {
    const nombre = document.getElementById('nombre_servicio');
    const descripcion = document.getElementById('descripcion');
    const categoria = document.getElementById('categoria');
    const productosSelect = document.getElementById('productos');
    const precio = document.getElementById('precio');
    const formulario = document.getElementById('formulario');

    // Agregar eventos de validación en tiempo real
    nombre.addEventListener('input', validarNombre);
    descripcion.addEventListener('input', validarDescripcion);
    categoria.addEventListener('change', validarCategoria);
    precio.addEventListener('input', validarPrecio);
    productosSelect.addEventListener('change', validarProductos);

    function validarNombre() {
        const valor = nombre.value;
        const errorDiv = document.getElementById('error_nombre_servicio');
        if (!/^[a-zA-Z\s]+$/.test(valor)) {
            errorDiv.textContent = 'El nombre solo debe contener letras y espacios.';
        } else {
            errorDiv.textContent = '';
        }
    }

    function validarDescripcion() {
        const valor = descripcion.value;
        const errorDiv = document.getElementById('error_descripcion');
        if (!valor.trim()) {
            errorDiv.textContent = 'La descripción es obligatoria.';
        } else {
            errorDiv.textContent = '';
        }
    }

 
    function validarPrecio() {
        const valor = precio.value;
        const errorDiv = document.getElementById('error_precio');
        if (!/^\d+(\.\d{1,3})?$/.test(valor)) {
            errorDiv.textContent = 'El precio debe ser un número con hasta 3 decimales.';
        } else {
            errorDiv.textContent = '';
        }
    }

    // Validar formulario completo antes de enviar
    formulario.addEventListener('submit', function(event) {
        if (!validarFormulario()) {
            event.preventDefault(); // Prevenir el envío del formulario si hay errores
        }
    });

    function validarFormulario() {
        validarNombre();
        validarDescripcion();
        validarCategoria();
        validarPrecio();
        validarProductos();

        const errorDivs = document.querySelectorAll('.error');
        return !Array.from(errorDivs).some(div => div.textContent !== '');
    }
});
