// Obtener elementos del DOM
var modal = document.getElementById('modal');
var agregarBtn = document.getElementById('agregarBtn');
var closeBtn = document.getElementsByClassName('close')[0];
var editarBtns = document.getElementsByClassName('editarBtn');

// Abrir modal al hacer clic en el botón Agregar
agregarBtn.onclick = function() {
    document.getElementById('id_perfil').value = '';
    document.getElementById('perfil').value = '';
    document.getElementById('descripcion').value = '';
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    checkboxes.forEach(checkbox => checkbox.checked = false);
    var perfilInput = document.getElementById('perfil');
    perfilInput.removeAttribute('readonly'); // Hacer el campo editable
    perfilInput.classList.remove('readonly'); // Eliminar la clase de readonly si estaba presente
    modal.style.display = 'block';
}

// Abrir modal al hacer clic en el botón Editar
for (let i = 0; i < editarBtns.length; i++) {
    editarBtns[i].onclick = function(event) {
        event.preventDefault(); // Prevenir el comportamiento predeterminado del enlace
        var id_perfil = this.getAttribute('data-id');
        fetch('perfiles.php?action=editar&id_perfil=' + id_perfil)
            .then(response => response.text()) // Esperar respuesta en formato de texto
            .then(data => {
                // Parsear el HTML recibido
                var parser = new DOMParser();
                var doc = parser.parseFromString(data, 'text/html');
                var perfilData = doc.getElementById('perfil_data');

                // Verificar si se obtuvo un error
                if (perfilData.getAttribute('data-error')) {
                    console.error(perfilData.getAttribute('data-error'));
                    return;
                }

                // Rellenar el formulario con los datos
                document.getElementById('id_perfil').value = perfilData.getAttribute('data-id');
                document.getElementById('perfil').value = perfilData.getAttribute('data-perfil');
                document.getElementById('descripcion').value = perfilData.getAttribute('data-descripcion');
                var modulos_acceso = perfilData.getAttribute('data-modulos_acceso').split(',');
                var checkboxes = document.querySelectorAll('input[type="checkbox"]');
                checkboxes.forEach(checkbox => {
                    checkbox.checked = modulos_acceso.includes(checkbox.value);
                });

                // Bloquear el campo 'perfil' para edición y aplicar estilo
                var perfilInput = document.getElementById('perfil');
                perfilInput.setAttribute('readonly', 'true');
                perfilInput.classList.add('readonly'); // Añadir la clase de readonly
                modal.style.display = 'block';
            })
            .catch(error => {
                console.error('Error al recuperar datos:', error); // Manejar errores de la solicitud fetch
            });
    }
}

// Cerrar modal al hacer clic en la 'X'
closeBtn.onclick = function() {
    modal.style.display = 'none';
}

// Cerrar modal si se hace clic fuera del contenido
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
