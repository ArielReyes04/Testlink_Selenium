       document.addEventListener('DOMContentLoaded', function () {
    var modal = document.getElementById("modalProducto");
    var btn = document.getElementById("anadirProductoBtn");
    var span = document.getElementsByClassName("close")[0];

    btn.onclick = function () {
        modal.style.display = "block";
        cargarProductos(); // Cargar productos cuando se abre el modal
    }

    span.onclick = function () {
        modal.style.display = "none";
    }

    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

   var modalProducto = document.getElementById("modalProducto");
var modalServicio = document.getElementById("modalServicio");

// Manejo del botón de cerrar para cada modal
modalProducto.querySelector('.close').onclick = function () {
    modalProducto.style.display = "none";
};

modalServicio.querySelector('.close').onclick = function () {
    modalServicio.style.display = "none";
};

// Cerrar el modal si se hace clic fuera de él
window.onclick = function (event) {
    if (event.target == modalProducto) {
        modalProducto.style.display = "none";
    }
    if (event.target == modalServicio) {
        modalServicio.style.display = "none";
    }
};
 document.getElementById('buscarClienteForm').addEventListener('submit', function (event) {
        event.preventDefault();
        var cedula = document.getElementById('cedula').value;

        fetch('ventas.php?action=buscar_cliente&cedula=' + encodeURIComponent(cedula))
            .then(response => response.json())
            .then(data => {
                var datosCliente = document.getElementById('datosCliente');
                datosCliente.innerHTML = '';

                if (data) {
                    datosCliente.innerHTML = `
                        <p><strong>Nombre:</strong> ${data.nombres}</p>
                        <p><strong>Cédula:</strong> ${data.cedula}</p>
                        <p><strong>Teléfono:</strong> ${data.telefono}</p>
                        <p><strong>Dirección:</strong> ${data.direccion}</p>
                        <p><strong>Email:</strong> ${data.email}</p>
                        <p><strong>Fecha de Nacimiento:</strong> ${data.fnac}</p>
                    `;
                } else {
                    datosCliente.innerHTML = '<p>Cliente no encontrado.</p>';
                }
            })
            .catch(error => console.error('Error al buscar cliente:', error));
    });

    // Cargar todos los productos desde la base de datos
    function cargarProductos() {
        fetch('ventas.php?action=load_productos')
            .then(response => response.json())
            .then(data => {
                var tablaProductos = document.getElementById('tablaProductos').getElementsByTagName('tbody')[0];
                tablaProductos.innerHTML = ''; // Limpiar tabla antes de cargar nuevos datos
                if (Array.isArray(data) && data.length > 0) {
                    data.forEach(producto => {
                        var fila = tablaProductos.insertRow();
                        fila.insertCell(0).textContent = producto.nombre_producto;
                        fila.insertCell(1).textContent = producto.codigo_producto;
                        fila.insertCell(2).textContent = producto.cantidad === 0 ? 'No disponible' : producto.cantidad;
                        fila.insertCell(3).textContent = producto.precio_unitario;
                        fila.insertCell(4).textContent = producto.descripcion;

                        // Celda para ingresar cantidad y botón Agregar
                        var cantidadCell = fila.insertCell(5);
                        if (producto.cantidad === 0) {
                            cantidadCell.textContent = 'No hay stock';
                        } else {
                            cantidadCell.innerHTML = `
                                <input type="number" min="1" value="1" class="cantidadInput" />
                                <button class="agregarBtn">Agregar</button>
                            `;
                            // Lógica para el botón Agregar
                            cantidadCell.querySelector('.agregarBtn').addEventListener('click', function () {
                                var cantidadInput = cantidadCell.querySelector('.cantidadInput');
                                var cantidad = parseInt(cantidadInput.value, 10);
                                if (cantidad > producto.cantidad) {
                                    alert('Productos insuficientes.');
                                } else {
                                    agregarProductoALaTablaVenta(producto, cantidad);
                                    actualizarStockEnBaseDeDatos(producto.codigo_producto, cantidad)
                                        .then(() => cargarProductos()); // Volver a cargar productos después de actualizar el stock
                                }
                            });
                        }
                    });
                } else {
                    var fila = tablaProductos.insertRow();
                    fila.insertCell(0).colSpan = 6;
                    fila.textContent = 'No hay productos disponibles.';
                }
            })
            .catch(error => console.error('Error al cargar productos:', error));
    }

   function agregarProductoALaTablaVenta(producto, cantidad) {
    var tablaVentas = document.getElementById('tablaVentas').getElementsByTagName('tbody')[0];
    var filas = tablaVentas.getElementsByTagName('tr');
    var productoEncontrado = false;

    for (var i = 0; i < filas.length; i++) {
        var fila = filas[i];
        var codigoProducto = fila.cells[1].textContent;
        if (codigoProducto === producto.codigo_producto) {
            // Actualizar cantidad si el producto ya está en la tabla
            var cantidadActual = parseInt(fila.cells[3].textContent, 10);
            var nuevaCantidad = cantidadActual + cantidad;
            fila.cells[3].textContent = nuevaCantidad;
            fila.cells[5].textContent = (nuevaCantidad * parseFloat(fila.cells[4].textContent)).toFixed(2);
            productoEncontrado = true;
            break;
        }
    }

    if (!productoEncontrado) {
        // Si el producto no está en la tabla, añadir una nueva fila
        var fila = tablaVentas.insertRow();
        fila.insertCell(0).textContent = producto.nombre_producto;
        fila.insertCell(1).textContent = producto.codigo_producto;
        fila.insertCell(2).textContent = producto.descripcion;
        fila.insertCell(3).textContent = cantidad;
        fila.insertCell(4).textContent = producto.precio_unitario;
        fila.insertCell(5).textContent = (cantidad * producto.precio_unitario).toFixed(2);

        // Agregar botón de eliminar
        var eliminarCell = fila.insertCell(6);
        eliminarCell.innerHTML = '<button class="eliminarBtn">Eliminar</button>';

        // Lógica para el botón Eliminar
        eliminarCell.querySelector('.eliminarBtn').addEventListener('click', function () {
            eliminarProductoDeLaTablaVenta(producto.codigo_producto, cantidad);
        });
    }

    // Actualizar totales después de agregar un producto
    actualizarTotales();
}

    // Función para eliminar producto de la tabla de detalle de venta
  function eliminarProductoDeLaTablaVenta(codigoProducto, cantidad) {
    var tablaVentas = document.getElementById('tablaVentas').getElementsByTagName('tbody')[0];
    var filas = tablaVentas.getElementsByTagName('tr');

    for (var i = 0; i < filas.length; i++) {
        var fila = filas[i];
        var codigoFila = fila.cells[1].textContent;
        if (codigoFila === codigoProducto) {
            // Restar la cantidad del producto eliminado
            var cantidadActual = parseInt(fila.cells[3].textContent, 10);
            var nuevaCantidad = cantidadActual - cantidad;
            if (nuevaCantidad <= 0) {
                tablaVentas.deleteRow(i); // Eliminar fila si la cantidad es cero o menor
            } else {
                fila.cells[3].textContent = nuevaCantidad;
                fila.cells[5].textContent = (nuevaCantidad * parseFloat(fila.cells[4].textContent)).toFixed(2);
            }
            // Actualizar el stock en la base de datos
            actualizarStockEnBaseDeDatos(codigoProducto, -cantidad)
                .then(() => cargarProductos()); // Volver a cargar productos después de actualizar el stock
            break;
        }
    }

    // Actualizar totales después de eliminar un producto
    actualizarTotales();
}

    // Función para actualizar el stock en la base de datos
    function actualizarStockEnBaseDeDatos(codigoProducto, cantidad) {
        return fetch('ventas.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                'action': 'actualizar_stock',
                'codigo_producto': codigoProducto,
                'cantidad': cantidad
            })
        })
        .then(response => response.text())
        .then(result => {
            console.log('Stock actualizado:', result);
        })
        .catch(error => console.error('Error al actualizar stock:', error));
    }
});

var modalServicio = document.getElementById("modalServicio");
    var btnServicio = document.getElementById("anadirServicioBtn");
    var spanServicio = modalServicio.getElementsByClassName("close")[0];

    btnServicio.onclick = function () {
        modalServicio.style.display = "block";
        cargarServicios(); // Cargar servicios cuando se abre el modal
    }

    spanServicio.onclick = function () {
        modalServicio.style.display = "none";
    }

    window.onclick = function (event) {
        if (event.target == modalServicio) {
            modalServicio.style.display = "none";
        }
    }

    // Cargar todos los servicios desde la base de datos
    function cargarServicios() {
        fetch('ventas.php?action=load_servicios')
            .then(response => response.json())
            .then(data => {
                var tablaServicios = document.getElementById('tablaServicios').getElementsByTagName('tbody')[0];
                tablaServicios.innerHTML = ''; // Limpiar tabla antes de cargar nuevos datos
                if (Array.isArray(data) && data.length > 0) {
                    data.forEach(servicio => {
                        var fila = tablaServicios.insertRow();
                        fila.insertCell(0).textContent = servicio.nombre;
                        fila.insertCell(1).textContent = servicio.descripcion;
                        fila.insertCell(2).textContent = servicio.productos;
                        fila.insertCell(3).textContent = servicio.precio;

                        // Celda para seleccionar el servicio
                        var seleccionarCell = fila.insertCell(4);
                        seleccionarCell.innerHTML = '<button class="seleccionarBtn">Seleccionar</button>';
                        // Lógica para el botón Seleccionar
                        seleccionarCell.querySelector('.seleccionarBtn').addEventListener('click', function () {
                            agregarServicioALaTablaVenta(servicio);
                            modalServicio.style.display = "none";
                        });
                    });
                } else {
                    var fila = tablaServicios.insertRow();
                    fila.insertCell(0).colSpan = 5;
                    fila.textContent = 'No hay servicios disponibles.';
                }
            })
            .catch(error => console.error('Error al cargar servicios:', error));
    }

    // Función para agregar servicio a la tabla de detalle de venta
    function agregarServicioALaTablaVenta(servicio) {
        var tablaVentas = document.getElementById('tablaVentas').getElementsByTagName('tbody')[0];
        var filas = tablaVentas.getElementsByTagName('tr');

        // Verificar si el servicio ya está en la tabla de ventas
        for (var i = 0; i < filas.length; i++) {
            var fila = filas[i];
            var idServicio = fila.cells[1].textContent;
            if (idServicio === servicio.id_servicio) {
                // Actualizar cantidad si el servicio ya está en la tabla
                var cantidadActual = parseInt(fila.cells[3].textContent, 10);
                var nuevaCantidad = cantidadActual + 1;
                fila.cells[3].textContent = nuevaCantidad;
                fila.cells[5].textContent = (nuevaCantidad * parseFloat(fila.cells[4].textContent)).toFixed(2);
                return;
            }
        }

        // Si el servicio no está en la tabla, añadir una nueva fila
        var fila = tablaVentas.insertRow();
        fila.insertCell(0).textContent = servicio.nombre;
        fila.insertCell(1).textContent = servicio.id_servicio;
        fila.insertCell(2).textContent = servicio.descripcion;
        fila.insertCell(3).textContent = 1; // Cantidad inicial
        fila.insertCell(4).textContent = servicio.precio;
        fila.insertCell(5).textContent = (1 * servicio.precio).toFixed(2);

        // Agregar botón de eliminar
        var eliminarCell = fila.insertCell(6);
        eliminarCell.innerHTML = '<button class="eliminarBtn">Eliminar</button>';

        // Lógica para el botón Eliminar
        eliminarCell.querySelector('.eliminarBtn').addEventListener('click', function () {
            eliminarServicioDeLaTablaVenta(servicio.id_servicio);
        });
    }

    // Función para eliminar servicio de la tabla de detalle de venta
    function eliminarServicioDeLaTablaVenta(idServicio) {
        var tablaVentas = document.getElementById('tablaVentas').getElementsByTagName('tbody')[0];
        var filas = tablaVentas.getElementsByTagName('tr');

        for (var i = 0; i < filas.length; i++) {
            var fila = filas[i];
            var idFila = fila.cells[1].textContent;
            if (idFila === idServicio) {
                tablaVentas.deleteRow(i); // Eliminar fila
                break;
            }
        }
    }
function actualizarTotales() {
    var tablaVentas = document.getElementById('tablaVentas').getElementsByTagName('tbody')[0];
    var filas = tablaVentas.getElementsByTagName('tr');
    var total = 0;

    for (var i = 0; i < filas.length; i++) {
        var fila = filas[i];
        var totalFila = parseFloat(fila.cells[5].textContent);
        total += totalFila;
    }

    var iva = total * 0.15;
    var precioFinal = total + iva;

    document.getElementById('totalVenta').textContent = total.toFixed(2);
    document.getElementById('ivaVenta').textContent = iva.toFixed(2);
    document.getElementById('precioFinal').textContent = precioFinal.toFixed(2);
}


function agregarProductoALaTablaVenta(producto, cantidad) {
    var tablaVentas = document.getElementById('tablaVentas').getElementsByTagName('tbody')[0];
    var filas = tablaVentas.getElementsByTagName('tr');

    for (var i = 0; i < filas.length; i++) {
        var fila = filas[i];
        var codigoProducto = fila.cells[1].textContent;
        if (codigoProducto === producto.codigo_producto) {
            var cantidadActual = parseInt(fila.cells[3].textContent, 10);
            var nuevaCantidad = cantidadActual + cantidad;
            fila.cells[3].textContent = nuevaCantidad;
            fila.cells[5].textContent = (nuevaCantidad * parseFloat(fila.cells[4].textContent)).toFixed(2);
            actualizarTotales();
            return;
        }
    }

    var fila = tablaVentas.insertRow();
    fila.insertCell(0).textContent = producto.nombre_producto;
    fila.insertCell(1).textContent = producto.codigo_producto;
    fila.insertCell(2).textContent = producto.descripcion;
    fila.insertCell(3).textContent = cantidad;
    fila.insertCell(4).textContent = producto.precio_unitario;
    fila.insertCell(5).textContent = (cantidad * producto.precio_unitario).toFixed(2);

    var eliminarCell = fila.insertCell(6);
    eliminarCell.innerHTML = '<button class="eliminarBtn">Eliminar</button>';

    eliminarCell.querySelector('.eliminarBtn').addEventListener('click', function () {
        eliminarProductoDeLaTablaVenta(producto.codigo_producto, cantidad);
    });

    actualizarTotales();
}

function eliminarProductoDeLaTablaVenta(codigoProducto, cantidad) {
    var tablaVentas = document.getElementById('tablaVentas').getElementsByTagName('tbody')[0];
    var filas = tablaVentas.getElementsByTagName('tr');

    for (var i = 0; i < filas.length; i++) {
        var fila = filas[i];
        var codigoFila = fila.cells[1].textContent;
        if (codigoFila === codigoProducto) {
            var cantidadActual = parseInt(fila.cells[3].textContent, 10);
            var nuevaCantidad = cantidadActual - cantidad;
            if (nuevaCantidad <= 0) {
                tablaVentas.deleteRow(i);
            } else {
                fila.cells[3].textContent = nuevaCantidad;
                fila.cells[5].textContent = (nuevaCantidad * parseFloat(fila.cells[4].textContent)).toFixed(2);
            }
            actualizarTotales();
            break;
        }
    }
}

function agregarServicioALaTablaVenta(servicio) {
    var tablaVentas = document.getElementById('tablaVentas').getElementsByTagName('tbody')[0];
    var filas = tablaVentas.getElementsByTagName('tr');

    for (var i = 0; i < filas.length; i++) {
        var fila = filas[i];
        var idServicio = fila.cells[1].textContent;
        if (idServicio === servicio.id_servicio) {
            var cantidadActual = parseInt(fila.cells[3].textContent, 10);
            var nuevaCantidad = cantidadActual + 1;
            fila.cells[3].textContent = nuevaCantidad;
            fila.cells[5].textContent = (nuevaCantidad * parseFloat(fila.cells[4].textContent)).toFixed(2);
            actualizarTotales();
            return;
        }
    }

    var fila = tablaVentas.insertRow();
    fila.insertCell(0).textContent = servicio.nombre;
    fila.insertCell(1).textContent = servicio.id_servicio;
    fila.insertCell(2).textContent = servicio.descripcion;
    fila.insertCell(3).textContent = 1;
    fila.insertCell(4).textContent = servicio.precio;
    fila.insertCell(5).textContent = (1 * servicio.precio).toFixed(2);

    var eliminarCell = fila.insertCell(6);
    eliminarCell.innerHTML = '<button class="eliminarBtn">Eliminar</button>';

    eliminarCell.querySelector('.eliminarBtn').addEventListener('click', function () {
        eliminarServicioDeLaTablaVenta(servicio.id_servicio);
    });

    actualizarTotales();
}

function eliminarServicioDeLaTablaVenta(idServicio) {
    var tablaVentas = document.getElementById('tablaVentas').getElementsByTagName('tbody')[0];
    var filas = tablaVentas.getElementsByTagName('tr');

    for (var i = 0; i < filas.length; i++) {
        var fila = filas[i];
        var idFila = fila.cells[1].textContent;
        if (idFila === idServicio) {
            tablaVentas.deleteRow(i);
            actualizarTotales();
            break;
        }
    }
}

		
		
function guardarFactura() {
    var cedulaCliente = document.getElementById('cedula').value;
    var tablaVentas = document.getElementById('tablaVentas').getElementsByTagName('tbody')[0];
    var filas = tablaVentas.getElementsByTagName('tr');

    // Verificar si hay al menos un producto en la tabla
    if (filas.length === 0) {
        alert('Debe agregar al menos un producto o servicio antes de guardar la factura.');
        return;
    }

    // Verificar que se ha ingresado una cédula de cliente
    if (!cedulaCliente) {
        alert('Debe ingresar una cédula de cliente.');
        return;
    }

    // Obtener datos de la tabla de ventas
    var productosIdCantidad = [];
    for (var i = 0; i < filas.length; i++) {
        var fila = filas[i];
        var codigo = fila.cells[1].textContent;
        var cantidad = parseInt(fila.cells[3].textContent, 10);
        productosIdCantidad.push({ codigo: codigo, cantidad: cantidad });
    }

    var totalSinIva = parseFloat(document.getElementById('totalVenta').textContent);
    var iva = parseFloat(document.getElementById('ivaVenta').textContent);
    var valorTotal = parseFloat(document.getElementById('precioFinal').textContent);

    // Enviar datos al servidor para guardar la factura
    fetch('ventas.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
            'action': 'guardar_factura',
            'cedula_cliente': cedulaCliente,
            'cedula_vendedor': 'Vendedor_Cedula', // Reemplaza con el valor real
            'productos_id_cantidad': JSON.stringify(productosIdCantidad),
            'total_sin_iva': totalSinIva,
            'iva': iva,
            'valor_total': valorTotal
        })
    })
    .then(response => response.text())
    .then(result => {
        alert(result);
        if (result === 'Factura guardada correctamente.') {
            // Limpiar la tabla de ventas en el cliente
            tablaVentas.innerHTML = '';
            document.getElementById('totalVenta').textContent = '0.00';
            document.getElementById('ivaVenta').textContent = '0.00';
            document.getElementById('precioFinal').textContent = '0.00';
            document.getElementById('cedula').value = ''; // Limpiar el campo de cédula del cliente
        }
    })
    .catch(error => console.error('Error al guardar la factura:', error));
}

// Función para obtener los productos y cantidades de la tabla
function getProductosIdCantidad() {
    var tablaVentas = document.getElementById('tablaVentas').getElementsByTagName('tbody')[0];
    var filas = tablaVentas.getElementsByTagName('tr');
    var productos = [];

    for (var i = 0; i < filas.length; i++) {
        var fila = filas[i];
        var codigoProducto = fila.cells[1].textContent;
        var cantidad = parseInt(fila.cells[3].textContent, 10);
        productos.push({ id: codigoProducto, cantidad: cantidad });
    }

    return productos;
}

// Función para obtener los servicios y cantidades de la tabla
function getServiciosIdCantidad() {
    var tablaVentas = document.getElementById('tablaVentas').getElementsByTagName('tbody')[0];
    var filas = tablaVentas.getElementsByTagName('tr');
    var servicios = [];

    for (var i = 0; i < filas.length; i++) {
        var fila = filas[i];
        var idServicio = fila.cells[1].textContent;
        var cantidad = parseInt(fila.cells[3].textContent, 10);
        servicios.push({ id: idServicio, cantidad: cantidad });
    }

    return servicios;
}



