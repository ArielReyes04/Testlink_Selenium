document.addEventListener('DOMContentLoaded', function() {
    var modal = document.getElementById("productModal");
    var btn = document.getElementById("openModal");
    var span = document.getElementsByClassName("close")[0];
    var form = document.getElementById("productForm");
    var modalTitle = document.getElementById("modalTitle");
    var formSubmitButton = document.getElementById("formSubmitButton");
    const categoryModal = document.getElementById('categoryModal');
    const openCategoryButton = document.getElementById('categoryButton');
    const closeCategoryButton = document.querySelector('.close-category');

    // Funciones de validación
    function validarNombreProducto() {
        const errorDiv = document.getElementById("nombre_producto-error");
        const nombrePattern = /^[A-Za-z\s]+$/;
        if (!nombrePattern.test(document.getElementById("nombre_producto").value)) {
            errorDiv.textContent = "El nombre del producto solo debe contener letras.";
            return false;
        } else {
            errorDiv.textContent = "";
            return true;
        }
    }

    function validarCodigoProducto() {
        const errorDiv = document.getElementById("codigo_producto-error");
        const codigoPattern = /^[A-Za-z0-9]+$/; // Puedes ajustar el patrón según tus necesidades
        if (!codigoPattern.test(document.getElementById("codigo_producto").value)) {
            errorDiv.textContent = "El código del producto solo debe contener letras y números.";
            return false;
        } else {
            errorDiv.textContent = "";
            return true;
        }
    }

    function validarCantidad() {
        const errorDiv = document.getElementById("cantidad-error");
        const cantidadPattern = /^\d+$/;
        if (!cantidadPattern.test(document.getElementById("cantidad").value) || document.getElementById("cantidad").value <= 0) {
            errorDiv.textContent = "La cantidad debe ser un número positivo.";
            return false;
        } else {
            errorDiv.textContent = "";
            return true;
        }
    }

    function validarPrecioUnitario() {
        const errorDiv = document.getElementById("precio_unitario-error");
        const precioPattern = /^\d+(\.\d{1,2})?$/; // Permite números con hasta 2 decimales
        if (!precioPattern.test(document.getElementById("precio_unitario").value)) {
            errorDiv.textContent = "El precio unitario debe ser un número válido con hasta dos decimales.";
            return false;
        } else {
            errorDiv.textContent = "";
            return true;
        }
    }

    function validarDescripcion() {
        const errorDiv = document.getElementById("descripcion-error");
        if (document.getElementById("descripcion").value.trim() === '') {
            errorDiv.textContent = 'La descripción es obligatoria.';
            return false;
        } else {
            errorDiv.textContent = '';
            return true;
        }
    }

    function validarCategoria() {
        const errorDiv = document.getElementById("categoria-error");
        if (document.getElementById("categoria").value.trim() === '') {
            errorDiv.textContent = 'La categoría es obligatoria.';
            return false;
        } else {
            errorDiv.textContent = '';
            return true;
        }
    }

    // Validaciones en tiempo real
    document.getElementById("nombre_producto").addEventListener('input', validarNombreProducto);
    document.getElementById("codigo_producto").addEventListener('input', validarCodigoProducto);
    document.getElementById("cantidad").addEventListener('input', validarCantidad);
    document.getElementById("precio_unitario").addEventListener('input', validarPrecioUnitario);
    document.getElementById("descripcion").addEventListener('input', validarDescripcion);
    document.getElementById("categoria").addEventListener('change', validarCategoria);

    // Abrir el modal de categorías
    openCategoryButton.addEventListener('click', () => {
        categoryModal.style.display = 'block';
    });

    // Cerrar el modal de categorías
    closeCategoryButton.addEventListener('click', () => {
        categoryModal.style.display = 'none';
    });

    // Cerrar el modal si se hace clic fuera del contenido
    window.addEventListener('click', (event) => {
        if (event.target === categoryModal) {
            categoryModal.style.display = 'none';
        }
    });

    // Abrir modal para agregar producto
    btn.onclick = function() {
        form.reset();
        document.getElementById("id").value = "";
        document.getElementById("codigo_producto").readOnly = false; // Hacer el campo editable
        modalTitle.textContent = "Agregar Producto";
        formSubmitButton.textContent = "Guardar";
        formSubmitButton.name = "guardar";
        modal.style.display = "block";
    }

    // Cerrar el modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // Cerrar el modal al hacer clic fuera de él
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Función para abrir modal en modo de edición
    window.openEditModal = function(product) {
        document.getElementById("id").value = product.id;
        document.getElementById("nombre_producto").value = product.nombre_producto;
        document.getElementById("codigo_producto").value = product.codigo_producto;
        document.getElementById("codigo_producto").readOnly = true; // Hacer el campo solo lectura
        document.getElementById("cantidad").value = product.cantidad;
        document.getElementById("precio_unitario").value = product.precio_unitario;
        document.getElementById("descripcion").value = product.descripcion;
        document.getElementById("fechaIngreso").value = product.fechaIngreso;

        modalTitle.textContent = "Editar Producto";
        formSubmitButton.textContent = "Actualizar";
        formSubmitButton.name = "editar";
        modal.style.display = "block";
    }

    // Validaciones al enviar el formulario
    form.addEventListener('submit', function(event) {
        if (!validarNombreProducto() || !validarCodigoProducto() || !validarCantidad() || !validarPrecioUnitario() || !validarDescripcion() || !validarCategoria()) {
            event.preventDefault(); // Evita que el formulario se envíe si hay errores de validación
        }
    });
});