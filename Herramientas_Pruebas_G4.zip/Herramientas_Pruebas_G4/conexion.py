from testlink import TestlinkAPIClient

# Configuración de la API de TestLink
TESTLINK_URL = "http://localhost/testlink/lib/api/xmlrpc.php"
TESTLINK_DEVKEY = "727ef81d296f2c390b1e783efa32bc32"  # Tu clave API generada

# Crear cliente de TestLink
testlink = TestlinkAPIClient(TESTLINK_URL, TESTLINK_DEVKEY)

# Probar la conexión con la API
try:
    print("Conexión exitosa con TestLink")
    print("Información de la API:", testlink.about())
except Exception as e:
    print("Error al conectar con TestLink:", e)
