/* 
$Revision: 1.1 $
$Date: 2007/04/24 14:24:50 $
$Author: franciscom $
$Name: testlink_1_9 $
*/
INSERT INTO db_version VALUES('1.7.0 RC 2', CURRENT_TIMESTAMP());