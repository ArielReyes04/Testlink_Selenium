/* 
$Revision: 1.1 $
$Date: 2007/01/31 14:14:56 $
$Author: franciscom $
$Name: testlink_1_9 $
*/
INSERT INTO db_version VALUES('1.7.0 Beta 4', now());