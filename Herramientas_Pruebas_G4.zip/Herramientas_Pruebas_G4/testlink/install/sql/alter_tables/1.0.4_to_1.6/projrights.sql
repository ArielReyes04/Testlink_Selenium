ALTER TABLE `projrights` MODIFY `userid` int(10) unsigned NOT NULL default '0';
ALTER TABLE `projrights` MODIFY `projid` int(10) unsigned NOT NULL default '0';

ALTER TABLE `projrights`  COMMENT='Updated to TL 1.6' ;




