/* 
$Revision: 1.2 $
$Date: 2007/10/19 06:53:06 $
$Author: franciscom $
$Name: testlink_1_9 $
*/
INSERT INTO db_version VALUES('DB 1.1', GETDATE());