/* 
$File:$
$Revision: 1.2 $
$Date: 2007/10/21 15:59:50 $
$Author: franciscom $
$Name: testlink_1_9 $
*/
ALTER TABLE testplans RENAME open TO is_open;