/* Update From 1.5.x to 1.6 */
ALTER TABLE `mgttestcase` MODIFY `title` varchar(100) default NULL;
ALTER TABLE `mgttestcase` COMMENT = 'Updated to TL 1.6';



